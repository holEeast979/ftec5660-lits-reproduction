# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

Starting from v0.2.11, version numbers in this changelog are kept in sync with `pyproject.toml`.

## 2026-10-22 Unreleased (`lits/benchmarks/persistence.py`)

### Changed
- Persistent benchmark runner: `benchmarks.persistence.run_benchmark_with_persistence`

## 2026-10-21 Unreleased (`lits/lm/transport.py`)

### Fixed
- Raw HTTPX server-error and HTTP 529 recovery

## 2026-10-17 Unreleased (`lits/components/reward/jev.py`)

### Changed
- JevPRM model pin: jev-1.14.0

## 2026-10-14 Unreleased (`lits/lm/transport.py`)

### Added
- Configurable network-recovery deadline and unlimited recovery

## 2026-10-12 Unreleased (`lits/benchmarks/cot.py`)

### Added
- CoT generation resume

## 2026-10-12 Unreleased (`lits/lm/transport.py`)

### Fixed
- HTTP 500 server-error recovery

## 2026-10-11 Unreleased (`lits/lm/transport.py`)

### Fixed
- HTTP 502/503/504 recovery
- CoT completion startup metadata recovery

## 2026-10-05 Unreleased (`lits/cli/cot_completion.py`)

### Added
- Multi-sample raw-completion CoT generation

## 2026-10-02 Unreleased (AIME24 dataset)

### Added
- Registered AIME24 benchmark dataset

## 2026-10-01 Unreleased (`lits/agents/tree/bfs.py`)

### Fixed
- Inclusive BFS terminal-count stopping threshold

## 2026-10-01 Unreleased (`lits/lm/transport.py`)

### Added
- One-hour network recovery, CRITICAL logging, and experiment exit on exhaustion

## 2026-10-01 Unreleased (AIME25 dataset)

### Added
- Registered AIME25 benchmark dataset

## 2026-10-01 Unreleased (`docs/jev/jev_for_prm.md`)

### Added
- Jev PRM demonstration and saved-candidate scoring evidence
- Registered Jev correctness-gated usefulness reward

## 2026-10-01 Unreleased (`0930-major-qwen3-8b-plain-beam-reproduction`)

### Fixed
- Prefix-verifier inference accounting role [T8.1]

## 2026-09-30 Unreleased (`0930-major-qwen3-8b-plain-beam-reproduction`)

### Added
- Raw-completion server compatibility checks [T1.1]
- OpenAI-compatible raw-completion model [T1.2]
- Raw-prefix continuation policy and serializable chunks [T2.1]
- Whole-prefix token-probability verifier and component registration [T2.2]
- Registered language-reasoning continuation prompt and MATH-100 cohort checks [T7.1]
- Raw single-pass CoT CLI with shared generation persistence [T7.2]
- MATH-100 CoT commands and saved-output evaluation checks [T7.3]

## 2026-09-30 Unreleased (`docs/lm/LLAMA_CPP_TAILSCALE_SETUP.md`)

### Changed
- Qwen3-8B Q8_0 Tailscale deployment documentation

## 2026-09-30 Unreleased (`demos/lits_benchmark/math_qa.py`)

### Added
- SciBench atkins, class, diff, fund, matter, quan, stat, and thermo dataset registrations

## 2026-09-29 Unreleased (`demos/lits_benchmark/math_qa.py`)

### Fixed
- SciBench chemistry alternating-series reference answer

## 2026-09-28 Unreleased (`demos/lits_benchmark/math_qa.py`)

### Added
- SciBench chemistry dataset registration

## 2026-09-28 Unreleased (`lits/eval/answer_voting.py`)

### Fixed
- Textual null labels in answer voting

## 2026-09-27 Unreleased (`lits/cli/cot.py`)

### Added
- Multi-sample CoT generation with uniform or per-example counts and shared answer voting

### Changed
- Shared CoT and concat-policy generation temperature default
- Thinking-enabled CoT answer voting

## 2026-09-26 Unreleased (`lits/components/reward/generative_json.py`)

### Added
- Native-tool GenerativeJSONPRM reward scoring (原生工具调用过程奖励评分)

## 2026-09-26 Unreleased (`lits/prompts/policy/concat.py`)

### Changed
- Shared reasoning and tool-retry instructions for concat policies (Concat 策略共享推理与工具重试指令)

## 2026-09-26 Unreleased (`lits/lm/openai_chat.py`)

### Added
- Explicit tool-choice forwarding (显式工具选择参数转发)

## 2026-09-26 Unreleased (`lits/prompts/reward/generative.py`)

### Changed
- Progress-based usefulness scoring instructions (基于实际推理进展的有用性评分指令)

## 2026-09-26 Unreleased (`lits/components/policy/concat_json.py`)

### Changed
- ConcatJSONPolicy reasoning-progress and completion instructions (ConcatJSONPolicy 推理进展与完成信号指令)

### Fixed
- ConcatJSONPolicy optional tool calls and mismatched retry fields (ConcatJSONPolicy 可选工具调用与重试字段不一致)

### Added
- Native-tool ConcatJSONPolicy with independent reward scoring (原生工具调用生成与独立奖励评分)

## 2026-09-26 Unreleased (`lits/components/policy/concat.py`)

### Fixed
- ConcatPolicy mathematical JSON escaping guidance and corrective retries (ConcatPolicy 数学 JSON 转义指引与纠错重试)
- Structured reasoning control-character validation (结构化推导控制字符校验)

## 2026-09-25 Unreleased (`lits/eval`)

### Changed
- Context-aware numerical tolerance in voting and judging (投票与评判中基于上下文的数值容差)

### Added
- CoT binary evaluation without a registered checker (无注册检查器时的 CoT 二元评判)

## 2026-09-25 Unreleased (`demos/lits_benchmark/math_qa.py`)

### Added
- Registered SciBench calculus dataset (注册 SciBench 微积分数据集)

## 2026-09-25 Unreleased (`lits/eval/general_eval.py`)

### Added
- Task context in correctness judging (正确性评判的任务上下文)

## 2026-09-24 Unreleased (`lits/eval/answer_voting.py`)

### Changed
- Required per-input voting labels (逐输入必填的投票标签)

## 2026-09-24 Unreleased (`lits/prompts/policy/concat.py`)

### Changed
- Joint-action reasoning prompt and `submit_reasoning_steps` tool schema (联合动作推导指令与工具格式)
- Joint-policy final-answer field guidance (联合策略最终答案字段指引)

### Fixed
- Parallel joint-policy tool calls causing search rejection (联合策略多工具调用导致搜索拒绝)
- Duplicate joint-reasoning candidates aborting search (重复推导候选导致搜索中断)

## 2026-09-24 Unreleased (`0919-major-unified-search-execution2/tasks`)

### Added
- Standalone CoT generation CLI (独立 CoT 生成 CLI) [T7.1]
- Shared-evaluator CoT CLI evaluation (复用共享 evaluator 的 CoT CLI 评估) [T7.3]

### Fixed
- Joint-action JSON parsing errors bypassing corrective retry (联合动作 JSON 解析错误绕过纠正重试) [T6.6]
- Duplicate voting-label rejection with valid membership (成员有效时重复投票标签导致的拒绝) [T5.4]

## 2026-09-23 Unreleased (`0923-major-joint-action-scoring/tasks`)

### Added
- ThoughtStep policy-score serialization [T1]
- Joint action generation with native tool calling [T2]
- Policy-score reward model [T3]
- Joint-action policy and policy-score reward component selection [T4]

### Fixed
- LiTS beam fallback scoring step metadata [T5]

## 2026-09-23 Unreleased (`0919-major-unified-search-execution2/tasks`)

### Added
- Caller-facts payload validation (调用方事实数据校验) [T3.4]
- Shared search spans with example/repetition identity (携带样本与重复编号的共享搜索跨度) [T4.1]
- Client registration during tracing configuration (tracing 配置时接入客户端) [T4.2]
- Opt-in executor-owned local tracing lifecycle (可选的执行器托管本地 tracing 生命周期) [T4.3]
- CLI configuration for local tracing (CLI 本地 tracing 配置开关) [T4.4]
- MCTS run and iteration tracing (MCTS 搜索与迭代 tracing) [T4.6]

### Changed
- Explicit legacy search-resume rejection (明确拒绝缺失完成状态的旧搜索结果恢复) [T3.5.1]
- Default benchmark error logging and continuation (benchmark 默认记录单样本错误并继续) [T3.5.2]

### Fixed
- Search resume query/repetition mismatch detection (搜索恢复时的问题与重复编号不匹配检查) [T3.5.3]
- Visible benchmark, method, and example identity in search traces (搜索 trace 显示 benchmark、方法与样本身份) [T4.8]
- Corrective retry for invalid answer-voting groups (答案投票分组无效时的纠正重试) [T5.2]
- Unanswered procedure handling in voting prompts (投票提示中未作答指令的处理) [T5.3]

## 2026-09-22 Unreleased (`0919-major-unified-search-execution2/tasks`)

### Added
- Shared search-facts persistence and execution status (共享搜索事实保存与执行状态) [T3.3]
- OS-lock-based active/interrupted search detection (基于操作系统锁区分运行中与中断搜索) [T3.3]

### Fixed
- Search errors hidden by partial-result returns (部分结果返回掩盖搜索异常) [T3.2]
- Skipped search cleanup on uncaught exceptions (未捕获异常跳过搜索清理) [T3.2]

### Removed
- Redundant `run_tree_search` entry point (合并到 `run_example` 的重复搜索入口) [T3.1]

## 2026-09-20 Unreleased (`0919-major-unified-search-execution2/tasks`)

### Changed
- Shared experiment configuration saving and conflict checking (共享实验配置保存与冲突检查) [T2.2]
- Configuration-derived per-example execution inputs (从完整配置派生单样本执行参数) [T2.2.1, T2.2.2]

### Added
- Caller-resolved query and initialization inputs for shared execution (共享执行支持调用方提供问题与初始化参数) [T1.7]

## 2026-09-19 Unreleased (`0919-major-unified-search-execution2/tasks`)

### Added
- Importable per-example search and saved-output workflow (可导入的单样本搜索与结果保存流程) [T1.2]
- Registered search-class lookup (注册搜索类查询) [T1.2]
- Search-result return from shared execution (共享执行返回搜索结果) [T1.5.1]
- Custom search arguments in shared execution (共享执行支持自定义搜索参数) [T1.5.2]
- Caller-owned search measurement context (调用方管理的搜索统计上下文) [T1.5.4]

### Changed
- CLI delegation to shared per-example execution (CLI 接入共享单样本执行函数) [T1.3]

### Fixed
- Missing BFS bucket-to-path serialization helper (BFS 分层节点转路径函数缺失) [T1.6]

## 2026-09-18 Unreleased (`0916-major-agent-runtime/tasks_observability`)

### Added
- Per-attempt tool execution tracing (每次工具执行尝试的追踪) [T3.2]
- Python logging forwarding to telemetry (Python 日志转发至遥测) [T3.3]
- Optional BFS spans and configurable snapshots (可选 BFS spans 与可配置快照) [T4.1]
- Selective offline telemetry archive copying (按 run ID 离线筛选遥测存档) [T5.2]
- Explicit saved-archive import into Logfire (显式导入已保存的遥测存档至 Logfire) [T5.3]

## 2026-09-17 Unreleased (`0916-major-agent-runtime/tasks_observability`)

### Added
- Optional observability dependencies (可选可观测性依赖) [T1.1]
- Optional tracing facade and local console spans (可选 tracing 接口与本地终端 spans) [T1.2]
- Local OTLP trace/log archives (本地 OTLP trace/log 存档) [T2.1]
- Configurable observation snapshots (可配置的观测快照) [T2.2]
- OpenAI client request tracing (OpenAI 客户端请求追踪) [T3.1]

### Changed
- Observability subpackage (可观测性子包) [T2.2.1]

## 2026-09-16 Unreleased (`0916-major-unified-search-execution/tasks`)

### Added
- Registry-based benchmark execution (基于注册机制的 benchmark 执行) [T9.1]

### Changed
- Search CLI delegation to the shared benchmark runner (搜索 CLI 接入共享 benchmark 执行函数) [T9.2.2]

## 2026-09-15 Unreleased (`0820-major-selection-interface/tasks`)

### Added
- Shared evaluation-result aggregation (共享评估结果汇总) [T7.6.1]
- Budget-curve analysis and plotting (预算曲线分析与绘图) [T7.6.2]
- Completed-run cost-threshold curves (完整运行结果的成本阈值曲线) [T7.6.3]

## 2026-09-14 Unreleased (`0820-major-selection-interface/tasks_task_adapters`)

### Added
- Registered DBBench value-only answer prompt (注册 DBBench 仅输出结果值的答案提示) [T8.3]
- SearchResult terminal-collection validation (SearchResult 终止节点集合校验) [T8.3]

### Fixed
- Score-plus-explanation reward replies incorrectly falling back to zero (附带解释的 reward 分数被误当作解析失败并回退为零) [T8.2.1]
- OpenAI-compatible newline stopping ignored by the wrapper (OpenAI 兼容封装忽略换行停止参数的问题) [T8.3]
- BFS cutoff endpoints incorrectly included in evaluation terminals (BFS 将截断节点误纳入待评估终止节点集合的问题) [T8.3]

## 2026-09-13 Unreleased (`0820-major-selection-interface/tasks_task_adapters`)

### Removed
- Legacy `get_fn_retrieve_answer()` wrapper and unused extraction helpers (旧版三层答案提取封装与不再使用的提取辅助函数) [T5.2.1]

### Changed
- Mandatory language-tree `voting_model` and shared CLI evaluation model (语言树评估必需的 voting_model 与 CLI 共享评估模型) [T5.2.1]
- Semantic-equivalence instructions for answer voting (答案投票的语义等价分组指令) [T5.2.1]
- CLI evaluation-model thinking configuration (CLI 评估模型的 thinking 配置) [T5.2.1]

### Fixed
- DBBench missing/blank predictions incorrectly matching zero (DBBench 缺失或空白答案误判为零值匹配) [T5.2.2]
- LLM fallback on rejected None/blank predictions (已判错的 None/空白答案触发 LLM 复核的问题) [T5.3.3]
- BFS configuration failure from MCTS-only defaults (MCTS 专用默认参数导致 BFS 配置构建失败的问题) [T6.2]

## 2026-09-12 Unreleased (`0820-major-selection-interface/tasks_task_adapters`)

### Added
- Registered MATH-500/GSM8K numeric correctness checker (注册 MATH-500/GSM8K 数值正确性检查器) [T5.3.2]
- Native tool-call responses in `OpenAIChatModel` (OpenAI 兼容模型的原生工具调用返回) [T5.2.1]
- Opt-in LLM answer grouping and deterministic vote counting (可选的 LLM 答案分组与确定性计票) [T5.2.1]

### Changed
- Deterministic-first optional LLM judging for language and tool-use evaluation (语言与工具任务先确定性检查，再按需调用 LLM 复核) [T5.3.1]
- Task-independent exact-string fallback in `check_answer()` (通用正确性检查默认使用精确字符串比较) [T5.3.2]
- QA comparison utilities moved to `lits_benchmark.math_qa_eval` (QA 比较工具移至独立 benchmark 评估模块) [T5.3.2]

## 2026-09-11 Unreleased (`0820-major-selection-interface/tasks_task_adapters`)

### Fixed
- Terminal ranking at negative infinity for missing/empty returns (缺失或空回传记录时的终点排序，改用 fast_reward) [T5.1]

## 2026-09-11 Unreleased (`x-0907-0911-minor-mcts-terminal-backpropagation`)

### Added
- MCTS lazy-answer transition and backup regression checks (延迟执行的 answer 节点遗漏 transition 与回传的回归测试) [T3.4]
- Ordered, selective MCTS path-end checks (按指定顺序执行的可选路径结束检查) [T3.4]

### Changed
- Per-search trajectory notification deduplication (每次搜索内按路径终点去重 trajectory 通知) [T2.2]
- Selected-node transition and completion callbacks (选中节点的 transition 与首次完成回调) [T3.4]
- Whole-search stopping via `terminate_on_first_solution` and `early_stop_reward` (统一全局停止配置，默认启用，质量门槛使用 `>=`) [T4.1]

### Removed
- `terminate_on_terminal_node` search argument (移除重复停止参数，旧配置需显式迁移) [T4.1]

### Fixed
- Pre-materialized terminal notifications skipped on selection (选中已执行 transition 的 terminal 时遗漏首次 trajectory 通知的问题) [T2.2]
- Selected lazy answers bypassing transition, terminal collection, and backup (选中的延迟执行 answer 节点跳过 transition、terminal 收集与回传的问题) [T3.4]
- Selected depth-bound actions skipping transition and evaluated-reward backup (深度边界上选中动作遗漏 transition 与已评估 reward 回传的问题) [T3.4]
- MCTS depth limits bypassed by reward thresholds or rollout entry (质量门槛或 rollout 入口绕过已启用深度限制的问题) [T3.2]
- Nonterminal depth/repetition cutoffs triggering completion-based search stopping (非 terminal 的深度截断或 repetition 错误触发整个搜索停止的问题) [T3.2]
- Reward-gated repetition path endings allowing extra expansion (质量门槛错误阻止 repetition 路径结束、导致额外 expansion 的问题) [T3.2]

## 2026-09-10 Unreleased (`0907-minor-mcts-terminal-backpropagation`)

### Added
- Regression case: low-score terminal exit rejected by `r_terminating` (低分 terminal 被搜索质量门槛拒绝退出当前迭代的回归用例) [T3.2]
- Regression case: `terminate_on_first_solution` bypassed before simulation (simulation 前已找到达标 terminal，却未按配置停止整个搜索的回归用例) [T3.2]

### Changed
- Expanded MCTS terminal-exit regression coverage across backup modes and callback presence (扩展已有 terminal 退出回归测试，覆盖不同回传模式及传入/省略 callback) [T2.2, T3.1]
- Continuation coverage: `terminate_on_terminal_node=True` (发现 terminal 后回传并保存，然后停止搜索) [T3.1]
- Continuation coverage: `terminate_on_terminal_node=False` (继续搜索；再次选中该 terminal 时回传并保存，不重复调用 completion callback) [T3.1]
- MCTS early-exit completion callback invocation (MCTS 提前结束当前迭代时的 completion callback 调用逻辑) [T2.2]
- Shared MCTS iteration finalization (MCTS 提前退出与 rollout 后共用回传、callback、trace 和 checkpoint 记录) [T3.2]

### Fixed
- Reward-threshold rejection of low-score terminal exits and downstream empty-child `argmax` failures (质量门槛拒绝低分 terminal 退出及后续 rollout 对空 children 执行 `argmax` 的问题) [T3.2]
- Qualifying terminals bypassing `terminate_on_first_solution` before simulation or `terminate_on_terminal_node` after rollout (达标 terminal 在 simulation 前绕过首个解停止配置、在 rollout 后绕过 terminal 停止配置的问题) [T3.2]

## 2026-09-07 Unreleased (`0907-minor-mcts-terminal-backpropagation`)

### Added
- MCTS terminal-completion and revisit regression checks (节点被判定为 terminal 及 terminal 再次被选中的回归测试) [T1.1, T1.2]
- MCTS early-exit recording regression checks (MCTS 提前结束当前迭代时，trace 与 checkpoint 记录的回归测试) [T2.2]

### Fixed
- MCTS selected-terminal backpropagation (MCTS 选中路径以 terminal 结束时的回传) [T2.1]
- MCTS early-exit callback and checkpoint ordering (MCTS 提前结束当前迭代时的 callback 调用与 checkpoint 保存顺序) [T2.2]

## 2026-09-06 Unreleased (`0820-major-selection-interface/tasks_task_adapters`)

### Added
- `lits.eval.search` terminal selection and answer retrieval helpers [T2.1]
- Tree-evaluation regression checks [T1, T2.1]
- `lits.eval.search.check_answer` and LLM judging helper [T2.2]
- Answer-checking regression checks [T2.2]
- `lits.eval.search.evaluate_search_result` [T2.3]
- CLI, in-memory, and reloaded-tree evaluation comparisons [T2.4]
- Live binary-fallback regression checks [T3.3]
- Chain/pass-at-N evaluation compatibility checks [T3.2]
- Live F1-fallback regression checks [T3.3]

### Changed
- CLI shared tree-result evaluation [T3.1]
- Shared evaluation usage in `docs/eval/CUSTOM_EVALUATORS.md` [T4]

### Fixed
- `select_env_terminal` nonterminal-input validation [T2.1]

## 2026-08-28 Unreleased (`0828-major-structured-policy-termination/tasks`)

### Added
- `ConcatTransition` step-signal termination [T1]
- `unit_test/components/test_concat_step_signal.py` [T1]
- `ConcatPolicy` structured `step`/`answer` output [T2]
- `unit_test/components/test_concat_structured_policy.py` [T2]

### Changed
- `Step.terminate` completion-signal contract [T1]
- `docs/components/transitions/TRANSITION.md` structured termination configuration [T1-T2]

### Fixed
- `ConcatPolicy` structured answer-prefix normalization [T2]

## 2026-08-28 Unreleased (`0820-major-selection-interface/tasks`)

### Fixed
- `ConcatTransition` empty termination-constraint validation [T7]

## 2026-08-27 Unreleased (`0820-major-selection-interface/tasks`)

### Added
- `SearchNode.get_path()` for reusable root-to-node path reconstruction [T5]
- `SearchNode.walk()` for reusable preorder tree traversal [T6]
- Inference metric field schema and snapshot subtraction utility [T6]

## 2026-08-26 Unreleased (`docs/lm/LLAMA_CPP_TAILSCALE_SETUP.md`)

### Added
- Private llama.cpp server setup over Tailscale

### Fixed
- Export `get_lm` lazily from the root `lits` package for the documented local-server client snippet

## 2026-08-26 Unreleased (`0820-major-selection-interface/tasks`)

### Added
- `BFSSearch._do_select_beam` and `MCTSSearch._do_select_path` selection hooks [T2]
- Default selection-hook regression checks [T2]

### Fixed
- `MemoryManager.list_inherited_units` docstring escape warning


## 2026-07-17 Unreleased (`0620-chore-memory-plumbing-audit/tasks`)

### Added
- Native memory-plumbing local verification checks [T2.1-T2.4]

### Fixed
- `pyproject.toml` — restore package version metadata to 0.4.0
- `NativeToolUseStep.verb_step` — include observations in native textual serialization [T1.1]
- `NativeToolUsePolicy` — deliver sibling context to native sync/async policy calls [T1.2-T1.5]
- `create_augmentors` — propagate effective tool-use task type to Reflection augmentor [T1.6]

## 2026-06-12 Unreleased (`docs/lm/bedrock_connectivity.md`)

### Fixed
- `Policy.get_actions` transient-error retry now also catches Bedrock `InternalServerException` (HTTP 500 server-side incident; waits and retries instead of crashing)

## 2026-06-10 Unreleased (`docs/lm/bedrock_connectivity.md`)

### Fixed
- `Policy.get_actions` transient-error retry now also catches Bedrock `ReadTimeoutError` (waits and retries instead of crashing the run)

## 2026-06-09 Unreleased (`0609-minor-react-terminal-tool`)

### Added
- `BaseTool.is_terminal` — mark a tool as a ReAct loop terminator; its validated args become the final structured answer [T1.1]
- `unit_test/agents/test_native_react_terminal_tool.py` [T3]

### Changed
- `_BaseNativeReAct._process_steps` — terminal tool calls end the loop with `json.dumps(action_input)` as the answer, without execution [T2]
- `docs/agents/NativeReAct.md` — document loop termination and terminal tools


## 2026-06-07 Unreleased (`docs/components/transitions/TOOL_FAILURE_HANDLING.md`)

### Added
- `BaseTool.server_down_retry_delays` — opt-in retry-with-backoff for transient tool-backend failures (default off)
- `lits/tools/utils.py::_attempt_tool_call` — single-attempt execute + server-down classification
- `docs/components/transitions/TOOL_FAILURE_HANDLING.md` — canonical tool-backend failure doc (classification + retry + breaker + operational recovery; merges former `CIRCUIT_BREAKER.md`)
- `unit_test/tools/test_server_down_retry.py`

### Changed
- `execute_tool_action` retries server-down failures per `server_down_retry_delays` before raising `ToolServerDownError`
- `_KGToolBase` opts into retry-with-backoff `(5, 15, 40, 60)` for SPARQL-over-tunnel reconnects (sized for slow cellular roaming)
- `bedrock_connectivity.md` scoped to Bedrock LLM-call failures; moved to `docs/lm/`; tool-backend content removed
- `README.md` Documentation list — added Tool Backend Failure Handling

### Removed
- `docs/components/transitions/CIRCUIT_BREAKER.md` (merged into `TOOL_FAILURE_HANDLING.md`)

## 2026-06-06 Unreleased

### Fixed
- `bedrock_chat.py`: added `connect_timeout=10` to the Bedrock client config. A stalled TCP connect (`SYN_SENT` after a network blip) previously held an already-signed SigV4 request with no timeout, causing either a multi-minute hang or an `InvalidSignatureException: Signature expired` crash when the request finally arrived >5 min after signing. The connect timeout caps the stall so adaptive retries re-sign with a fresh timestamp.

### Added
- `docs/cli/debug_guide/bedrock_connectivity.md` — catalogs the five observed Bedrock/transient-failure signatures (ReadTimeout, InternalServerException, tool URLError, SYN_SENT hang, Signature expired), a triage decision tree, verification commands, and operational mitigations (`caffeinate`, autossh keepalive)

## 2026-06-05 Unreleased

### Added
- `lits-resume-clean` CLI (`lits/cli/resume_clean.py`) — automates resume.md Procedure 3+4 for interrupted `lits-search` runs: detects incomplete examples (via checkpoints AND inferencelogger records, so early crashes with no checkpoint are caught), archives their checkpoints, and filter-splits stale records out of inferencelogger/llm_calls/execution logs. Regression test in `unit_test/cli/test_resume_clean.py`
- `BaseTool.classify_string_result_as_server_down` class attribute (default `True`) — lets tools opt out of string-return server-down classification
- Regression tests `case_m_shell_output_with_connect_error_opts_out`, `case_n_same_output_without_optout_is_server_down` (`unit_test/components/transition/test_tool_server_down_classify.py`)
- `docs/components/transitions/CIRCUIT_BREAKER.md` Gotcha 4 — shell-tool output is not a backend-health signal

### Changed
- Renamed `docs/cli/resume_qa.md` → `docs/cli/resume.md` and restructured it to lead with the `lits-resume-clean` CLI
- README: listed `lits-resume-clean` under CLI Commands; removed the outdated demo-video section (command arguments have since changed)

### Fixed
- Circuit breaker false-positive on shell-tool output — `execute_tool_action` string-return classification now respects the per-tool `classify_string_result_as_server_down` flag; `ShellTool` (Terminal-Bench) opts out so command output containing "connect"/"error"/"404" (e.g. wget hitting a 404) no longer trips the breaker (`lits/tools/base.py`, `lits/tools/utils.py`, `demos/lits_benchmark/terminal_bench_tools.py`)

## 2026-06-04 0.4.0

### Milestone
- Consolidated the `dev/context-augmentor` line into `main` and published to the public `origin` (github.com/xinzhel/lits-llm); retired the temporary `lits-mem` remote. This brings cross-trajectory memory, native ReAct, KGQA/Terminal-Bench integration, the BN-evaluator continuation, and the tool-failure circuit breaker into the public release line.

### Added
- README now surfaces three previously-undocumented features with copy-paste CLI examples and doc links: BN-evaluator Chain-in-Tree continuation (`bn_method`), cross-trajectory memory (`--memory-arg augmentors=fact|reflection`), and sibling-aware expansion (`search_algorithm=mcts_sibling_aware`)


## 2026-06-04 0.4.0 (`0527-minor-cross-model-replication`)

### Fixed
- `bedrock_chat.py`: Bedrock client now uses adaptive retries (`max_attempts=5`) so transient `ReadTimeoutError`/throttling/5xx no longer crash a run mid-experiment

## 2026-06-01 0.4.0 (`0527-minor-cross-model-replication`)

### Changed
- `bedrock_chat.py`: Converse API routing now includes Qwen, MiniMax, Moonshot, Z.AI models (previously only Anthropic/Amazon/Meta/Mistral/Cohere/AI21) [T1]

### Fixed
- Circuit breaker false-positive on application-level HTTP 5xx — `_classify_as_server_down` now excludes 5xx responses whose body indicates a query/application error (e.g. Virtuoso `S0022 Error SQ200` on complex SPARQL) while still classifying bare 5xx and transport failures as server-down (`lits/tools/utils.py`)

### Added
- Regression tests `case_k_http_500_application_query_error_is_not_server_down`, `case_l_http_500_no_application_marker_is_server_down` (`unit_test/components/transition/test_tool_server_down_classify.py`)
- `docs/components/transitions/CIRCUIT_BREAKER.md` Gotcha 3 — application-level HTTP 500 vs genuine server-down

## 2026-05-30 0.4.0

### Added
- `FactMemoryAugmentor.trigger_mode` parameter (`per_step` | `per_trajectory`) — controls whether fact extraction runs after each transition step (cross-branch sharing) or after each MCTS iteration completes (cross-iteration sharing)
- CLI flag `--memory-arg fact_trigger=per_trajectory` to select per-trajectory mode under `lits-search`
- Per-example memory persistence in `lits-search`: `backend.save()` called after each example, writing facts to `memory/{query_idx}/` for post-hoc inspection

### Changed
- `augmentor_setup.py`: augmentor classification now uses `_classify_augmentor()` function instead of hardcoded type tuples; `FactMemoryAugmentor` routed based on `trigger_mode`
- `on_trajectory_complete` passes `batch=True` to `FactMemoryAugmentor` so all trajectory steps are extracted in one call


## 2026-05-23 0.4.0

### Fixed
- Circuit breaker false-positive on HTTP 4xx — `_classify_as_server_down` now skips `urllib.error.HTTPError(code in 400..499)` while still classifying 5xx and chained underlying network errors as server-down (`lits/tools/utils.py`)
- `lits-search` resume no longer re-runs `resolve_answer` on already-completed examples — saves SPARQL calls and silences spurious "variable #N not found" warnings during resume (`lits/cli/search.py`)

### Added
- `docs/components/transitions/CIRCUIT_BREAKER.md` — documentation of classification logic, the HTTP 4xx gotcha, autossh-based tunnel recovery
- Regression tests `case_i_http_4xx_is_not_server_down`, `case_j_http_5xx_is_server_down` in `unit_test/components/transition/test_tool_server_down_classify.py`

### Changed
- `docs/cli/resume_qa.md` Procedure 4 expanded to cover all four append-mode files (`inferencelogger.log`, `llm_calls.jsonl`, `execution.log`, `treetojsonl*.jsonl`), with pre-flight idx-counts sanity check and multi-example batched cleanup pattern


## 2026-05-22 0.4.0 (`x-0522-0522-minor-tool-failure-circuit-breaker`)

### Added
- `ToolServerDownError` exception (`lits/tools/utils.py`, exported from `lits.tools`)
- Tool backend circuit breaker in `ToolUseTransition` (`tool_failure_threshold`, default 3)
- Server-down classification in `execute_tool_action` (whitelist of network exceptions + string-marker fallback)

### Changed
- `execute_tool_action` — removed `raise_on_error` parameter; signature is `(action_data, tools)`
- `lits/agents/chain/native_react.py` — chain caller now catches `ToolServerDownError` explicitly and surfaces as observation


## 2026-05-20 0.4.0

### Fixed
- `Policy._get_actions` transient-error retry — also retry on transient network failures (`EndpointConnectionError`, `NameResolutionError`, `socket.gaierror`); previously these terminated long runs after a wifi drop. See `chore/aws/bedrock/debug/dns_resolution_failure.md`


## 2026-05-19 0.4.0 (`0519-minor-bedrock-validation-fix`)

### Fixed
- `_response_to_steps` — split parallel tool calls into per-step `assistant_message_dict` (each with one `toolUse` block) to fix "missing toolResult" ValidationException (`lits/components/policy/native_tool_use.py`) [T1]
- `_response_to_steps` — validate tool names against Bedrock constraint; hallucinated names (e.g., `sql_db_\n_query`) produce error steps instead of tainting conversation history [T2]

### Docs
- `docs/agents/NativeReAct.md` — updated parallel tool calls section to reflect per-step splitting design [T1]
- `unit_test/components/test_response_to_steps.py` — rewritten with full coverage for parallel calls, tool name validation, and _build_messages [T4]


## 2026-05-19 0.4.0

### Added
- `lits-eval --terminal_selection {first|q-max|q-mean}` flag — controls which terminal node's answer is evaluated for tool_use tasks. Default `q-mean` matches `MCTSNode.DEFAULT_Q_FUNC` (np.mean) used during UCT. `q-max` uses argmax over max(cum_rewards). `first` reproduces the legacy save-order-dependent behaviour (`terminal_nodes[0]`)
- `BaseTreeSearch.save_full_tree()` — serializes the entire search tree (all nodes incl. un-simulated siblings) to `full_tree/full_tree_{query_idx}.json` after search completes. Called automatically in MCTS; no-op when checkpointing is disabled (`lits_mem/0520-minor-save-full-tree`)

### Fixed
- `lits/cli/eval_search.py` `is_tool_use` branch — replace `terminal_nodes[0]` (save-order dependent) with PRM-best selection. Previously, MCTS runs that saved a degenerate root-thinking placeholder before deeper SQL trajectories had their accuracy under-reported by 8–14 percentage points (verified on three WikiSQL runs)
- `setup_inference_logging` in `lits/cli/search.py` — also attach the logger to `augmentor_base_model` (reflection LLM); previously only `memory_llm` was registered, causing reflection LLM costs to be silently missing from `inferencelogger.log`

### Docs
- `docs/cli/debug_guide/pilot_check.md` — added cost coverage check (verify `inferencelogger.log` records every paid LLM before scaling pilots)


## 2026-05-18 0.4.0

### Added
- `_parse_value` — accept `None`/`null` as literal Python `None` for `--search-arg`/`--component-arg`/`--cfg`

### Fixed
- `create_augmentors` — forward `reward_threshold` and `task_type` from `--memory-arg` to `ReflectionAugmentor`
- MCTS augmentor wiring — `augmentor_query_context` now reads `policy_model_name` from `self.policy.base_model.model_name` and `task_type` from `self.policy.TASK_TYPE` (fixes `store() skipped` bug)
- `NativeToolUsePolicy.TASK_TYPE` — corrected from `"native_tool_use"` to `"tool_use"`
- `Policy._get_dynamic_notes` — join `List[str]` with newline before injection (removes spurious `["..."]` brackets in system prompt)
- `BedrockChatModel._converse_api` — return empty response on `ValidationException` instead of crashing (resilience for malformed tool calls from LLM hallucination)

## 2026-05-11 0.4.0 (`lits_mem/0511-minor-mcts-uct-fix`)

### Fixed
- `_uct_select` — unvisited children now receive +∞ priority; `ln(N_p)` clamped via `max(2, N_p)` [T1]

## 2026-05-11 0.4.0 (`lits_mem/0509-major-mcts-native-tool-use`)

### Fixed
- `NativeToolUsePolicy._build_messages` — seed query as first user message when state is empty (MCTS root node) [T2]
- `ToolUsePRM` — accept `BaseToolUseStep` (both `ToolUseStep` and `NativeToolUseStep`) in `_fast_reward` and `_complete_trajectory` [T6]
- `lits-search` — move `clean_result_dir` before `setup_logging` so `execution.log` file handler is not orphaned by a later `rmtree`

### Added
- `BaseToolUseStep` and `NativeToolUseStep` exported from `lits.structures` [T6]

## 2026-05-10 0.4.0 (`lits_mem/0509-major-mcts-native-tool-use`)

### Changed
- `BaseToolUseStep.think` [T1]
- `docs/structures/STRUCTURES.md` — tool-use hierarchy + round-trip caveat [T1]
- `NativeToolUsePolicy._get_actions` — loop N times to sample `n_actions` steps [T2]
- `AsyncNativeToolUsePolicy._get_actions` — `asyncio.gather` for concurrent sampling [T2]
- `_response_to_steps` — preserve reasoning text alongside tool_calls in `think` [T3]
- `create_components_tool_use` — select `NativeToolUsePolicy` when `config.native=True` [T5]

### Added
- `unit_test/components/test_response_to_steps.py` [T3]
- `ExperimentConfig.native` + promoted `native` from `ChainConfig` to `BaseConfig` [T4]

## 2026-05-08 0.4.0

### Added
- `docs/lm/NATIVE_TOOL_USE_ISSUES.md` — garbled LLM output → ValidationException documentation
- `TerminalBenchEnv.DEFAULT_CMD_TIMEOUT` (300s) per-command cap in `demos/lits_benchmark/terminal_bench.py`
- Harbor cache structure docstring in `demos/lits_benchmark/terminal_bench.py`

### Fixed
- `lits/cli/chain.py`: verify failure now always writes `reward=0.0` (prevents infinite re-run on resume)
- `lits/cli/chain.py`: catch `ValidationException` from garbled LLM output → auto-skip attempt with reward=0 instead of crashing
- `lits/components/base.py`: retry loop for transient errors (SSO expired, ServiceUnavailable, Throttling) in `get_actions`

## 2026-05-06 0.4.0

### Added
- `docs/cli/resume_qa.md` — guide for handling interrupted checkpoints (verifier vs no-verifier `lits-chain` regimes, `_uncomplete` rename recipe, `lits-search` resume behavior, inference log hygiene on resume)

### Changed
- Fix `lits-eval` passing `str(ground_truth)` to custom evaluators — now passes raw object directly (`eval_search.py`)
- Document evaluator signature contract: `ground_truth` type matches `example["answer"]` from dataset loader (`docs/eval/CUSTOM_EVALUATORS.md`)
- Pin `huggingface-hub>=0.30.2,<1.0` and `sentence_transformers>=5.3.0` in `pyproject.toml`

## 2026-05-05 0.4.0 (`0302-agentbench-integration/tasks_dbbench_reflection`)

### Fixed
- `search.py` — reflection augmentor wiring for `lits-search` (was missing `base_model`, crashed on `--memory-arg augmentors=reflection`)
- `search.py` — memory manager only created when fact augmentor is requested (avoids unnecessary LLM init for reflection-only runs)

## 2026-05-03 0.4.0 (`0302-agentbench-integration/tasks_dbbench_reflection`)

### Changed
- `backends.py::_FACT_EXTRACTION_PROMPT` — rewritten to extract reusable environmental knowledge (schemas, column names, query results) instead of generic action descriptions

### Added
- `docs/cli/debug_guide/pilot_check.md` — pilot verification guide (augmentor output, policy injection, behavior effect)
- `docs/components/context_augmentor/FACT_MEMORY.md` — FactMemoryAugmentor documentation (recording modes, memory scope, CLI usage)

## 2026-05-02 0.4.0 (`0302-agentbench-integration/tasks_dbbench_reflection`)

### Changed
- `eval_search.py` — refactored eval pipeline: unified single-attempt and pass@N into one eval loop
- `eval_search.py` — extracted `_parse_checkpoint_filename()`, `_should_include_file()`, `_discover_checkpoint_files()` helpers
- `eval_search.py` — extracted `_check_answer()` with `(correct, score)` return for shared evaluator logic (custom + LLM fallback)
- `eval_search.py` — extracted `_create_llm_evaluator()` and `_save_eval_results()` helpers
- `eval_search.py` — `_should_include_file()` now rejects unknown filename patterns (e.g. `1_a2_incomplete.json`)

### Added
- `eval_search.py` — `eval_results.json` output for both single-attempt and pass@N runs
- `eval_search.py` — LLM evaluator support for pass@N (was missing, caused 0% on DBBench)
- `eval_search.py` — fail-fast on botocore SSO/auth errors (no longer silently produces 0 examples)

## 2026-04-28 0.4.0 (`0302-agentbench-integration/tasks_kg_reflection`)

### Fixed
- `chain.py` — resume logic: when no `verify_fn`, checkpoint existence = complete (was re-running no-answer completions)

## 2026-04-27 0.4.0 (`0302-agentbench-integration/tasks_kg_reflection`)

### Changed
- `reflection.py::_build_reflection_message` — neutral prompt language when `reward=None` (no verifier)
- `reflection.py::retrieve()` — header changed to "Reflections from previous attempts:" (neutral)
- `eval_search.py` — pass@N checkpoint detection and evaluation (auto-detects `{idx}_a{attempt}.json` files, outputs `pass_at_n_summary.json`)

### Fixed
- `AgentBench/sparql_executer.py` — replaced `exit(0)` on URLError with `raise RuntimeError` (11 occurrences)
- `react.py` — `%d` → `%s` format for `query_idx` logging (pass@N sends string like "0_a0")

### Added
- `docs/components/context_augmentor/REFLECTION.md` — `verify_fn` design rationale (environment feedback vs gold answer comparison)
- `run_experiments_kgqa.sh` — Exp #6 (independent traj + reflection) and #7 (beam search + reflection) commands
- `.kiro/specs/lits_mem/0302-agentbench-integration/tasks_kg_reflection.md`
- `.kiro/specs/lits_mem/0302-agentbench-integration/tasks_dbbench_reflection.md`

## 2026-04-25 0.4.0 (`0421-minor-terminalbench-memory-exploration/tasks_reflection`)

### Changed
- `create_augmentors()` — `memory_manager` now optional (reflection-only mode) [T1.1]
- `_analyze_trajectory()` — accepts `reward` and `query_or_goals` for ReflectionAugmentor [T1.3]
- Chain augmentor setup: conditional `memory_manager`/`base_model` creation based on augmentor names [T1.2]
- `query_context` update gated on `if augmentors` instead of `if memory_manager` (works for reflection-only) [T1.4]
- `query_context["query_or_goals"]` added for ReflectionAugmentor.retrieve() [T1.4]

### Fixed
- `ReflectionAugmentor.retrieve()` reads `query_idx` from `query_context` (was `query_id`, key mismatch)
- `VALID_ROLES_PREFIX` — added `augmentor` (ReflectionAugmentor InferenceLogger role was rejected)
- `flush_threshold` default changed to 1 (was 0 in base, 5 in ReflectionAugmentor) — flush after every analyze
- Added `flush_buffer()` call at end of chain run (safety net for any remaining buffer entries)
- Added `flush_buffer()` call at end of search run (same safety net)
- `docs/components/context_augmentor/REFLECTION.md` — added execution.log debugging guide
- `_BaseNativeReAct._process_steps` — shared parallel tool call handling for sync and async NativeReAct
- `_response_to_steps` — only first step carries `assistant_message_dict` for parallel tool calls

### Added
- `docs/components/context_augmentor/REFLECTION.md` — reward semantics, chain vs search setup
- Augmentor persistence to `result_dir/augmentor/` via `save_dir` in `query_context`
- `query_context` now sets `policy_model_name` and `task_type` in chain (enables jsonl persistence)

## 2026-04-23 0.4.0 (`0421-minor-terminalbench-memory-exploration`)

### Fixed
- Memory LLM InferenceLogger wired to same log file as policy model in `lits-chain`
- `NativeToolUsePolicy` receives `tool_context` as system prompt (was `None`)
- `NativeReAct.run()` uses `policy.get_actions()` (dynamic notes injection via `set_system_prompt`)
- `_parse_facts_response` — robust JSON extraction from LLM responses (greedy regex, noise filtering)
- `--override` in `lits-chain` cleans entire result dir (shared `clean_result_dir`)

### Added
- Per-attempt memory snapshots saved to `{result_dir}/memory/{idx}_a{attempt}/`
- Memory resume from disk on process restart

## 2026-04-22 0.4.0 (`0421-minor-terminalbench-memory-exploration`)

### Changed
- `setup_memory_manager()` — removed `config` parameter and `enable_memory` check; pure factory function
- `create_augmentors()` — new shared function in `lits/cli/search.py`; reads `--memory-arg augmentors=fact,reflection`
- Removed `enable_memory` and `memory_config` from `ExperimentConfig`
- `FactMemoryAugmentor.analyze()` — added `batch=True` mode for whole-trajectory fact extraction
- `augmentor_setup.py` — split `setup_augmentors` into `wire_retrieval_to_policy` + `build_search_callbacks`
- `chain.py` — use shared `setup_memory_manager` + `create_augmentors` + `wire_retrieval_to_policy`; batch `_analyze_trajectory`
- `FactMemoryAugmentor` — added `skip_similarity_filtering` for chain pass@N (return all prior facts)
- `LiTSMemoryManager.build_augmented_context` — `skip_similarity_filtering` param, `AugmentedContext.all_prior_units` field
- Rewrote `docs/eval/OUTPUT_FILES.md` — added lits-chain output structure, result dir management, updated to current CLI/log formats

### Fixed
- `NativeToolUsePolicy.set_system_prompt` — inject dynamic notes (memory context) even when `task_prompt_spec` is None
- `--override` in `lits-chain` now cleans the entire result directory (shared `clean_result_dir` with `lits-search`)
- `NativeReAct.run()` — use `policy.get_actions()` instead of `policy._get_actions()` (was bypassing `set_system_prompt`, memory injection, logging)

## 2026-04-19 0.4.0 (`0419-minor-pass-at-n`)

### Added
- `n_attempts` field on `ChainConfig` — pass@N evaluation via `--cfg n_attempts=5`
- Attempt loop in `_run_tool_use` with unique checkpoint naming (`{idx}_a{attempt}`)
- `pass_at_n_summary.json` generation after all attempts complete
- Temperature auto-set to 0.9 when `n_attempts>1` (follows Golubev et al. ICML 2025)
- `NativeReAct` accepts `temperature` parameter (was hardcoded to 0.0)
- Skip completed attempts on resume: checks checkpoint for answer before re-running
- `NativeReAct.run()`: set `policy._query_idx` before calling `_get_actions` (fixes missing example ID in inferencelogger.log role field)

## 2026-04-19 0.4.0 (`0418-minor-sync-native-react`)

### Added
- `NativeReAct` (sync) via `_BaseNativeReAct` shared base (`lits/agents/chain/native_react.py`)
- `native=True` parameter on `create_tool_use_agent()` — switches from `ReActChat` to `NativeReAct`
- CLI support: `lits-chain --dataset terminal_bench --cfg native=True`
- `unit_test/agents/test_sync_native_react.py`

### Changed
- `from_tools()` on both `NativeReAct` and `AsyncNativeReAct` now requires full model key with provider prefix (e.g., `bedrock/...`)

### Fixed
- `NativeReAct.run()`: added `override` param (was missing, caused `TypeError` from `lits-chain`)
- `_load_or_init_state()`: added `override` param to skip checkpoint loading when `True`
- `ChainConfig`: added `native: bool` field so `--cfg native=True` is recognized (was silently ignored)
- `BedrockChatModel`: `read_timeout=300s` (was 60s default, too short for long code generation)
- Native tool call response logging in `_converse_api()`
- `_run_tool_use`: inline verification after agent.run() — calls `verify` callback while container is alive, saves reward to `{idx}_reward.json`
- `load_terminal_bench_resource`: added `verify` callback that runs `test.sh` in container

## 2026-04-18 0.4.0 (`0418-minor-sync-native-react`)

### Added
- Native tool use support for sync `BedrockChatModel`: `tools` param on `__call__`/`_converse_api`, `_build_tool_config()`, `format_tool_result()`
- `ToolCallOutput.__repr__()` (`lits/lm/base.py`)
- `NativeToolUsePolicy` (sync) via `_BaseNativeToolUsePolicy` shared base (`lits/components/policy/native_tool_use.py`)
- `unit_test/models/test_bedrock_tool_use.py`
- `unit_test/components/test_sync_native_tool_use_policy.py`

### Changed
- Refactored `AsyncNativeToolUsePolicy` to inherit from `_BaseNativeToolUsePolicy` (no behavior change)
- Extracted `_response_to_steps()` shared helper
- Renamed `docs/agents/AsyncNativeReAct.md` → `docs/agents/NativeReAct.md`, added design decisions
- `aioboto3` added to `pyproject.toml`
- Fixed empty-state bug in `unit_test/components/test_native_tool_use_policy.py` (pre-existing from `f8a1b27`)

## 2026-04-18 0.4.0 (`0415-terminalbench-integration`)

### Added
- `TerminalBenchEnv` (`demos/lits_benchmark/terminal_bench.py`) — Docker container lifecycle for Terminal-Bench 2.0 tasks
- `ShellTool` (`demos/lits_benchmark/terminal_bench_tools.py`) — BaseTool subclass for bash command execution
- `@register_dataset("terminal_bench")` — dataset loader for 89 Terminal-Bench 2.0 tasks from Harbor cache
- `@register_evaluator("terminal_bench")` — verifier-based evaluation (test.sh → reward.txt)
- `@register_resource("terminal_bench")` — resource registration with per-task container switching via `prepare_tool_state`
- `unit_test/tools/test_terminal_bench.py`

### Changed
- `load_terminal_bench_resource` uses `_ShellToolProxy` for per-task container switching (compatible with `lits-chain`)
- `@register_evaluator("terminal_bench")` — verifier-based evaluation (test.sh → reward.txt)
- `@register_resource("terminal_bench")` — resource registration wiring ShellTool + TerminalBenchEnv
- `unit_test/tools/test_terminal_bench.py`

## 2026-04-16 0.4.0

### Added
- `AsyncNativeReAct` (`lits/agents/chain/native_react.py`) — async/streaming ReAct agent with `from_tools()` factory, `run_async()`, `stream()`
- `_get_actions_stream()` on `AsyncNativeToolUsePolicy` — streaming version reusing `_build_messages()` + `set_system_prompt()`
- `docs/agents/AsyncNativeReAct.md` — documentation for native tool use architecture

### Changed
- Renamed `NativeToolUsePolicy` → `AsyncNativeToolUsePolicy`, `NativeReAct` → `AsyncNativeReAct`
- `AsyncNativeToolUsePolicy.set_system_prompt()` override to support `AsyncBedrockChatModel`

### Fixed
- `_build_messages()` no longer appends query at end (query is already in state as `NativeToolUseStep(user_message=...)`)
- `stream()` text accumulation bug: text before tool calls no longer treated as final answer

## 2026-04-15 0.4.0

### Added
- `AsyncBedrockChatModel` (`lits/lm/async_bedrock.py`) — async Bedrock client with native tool use and streaming via `converse_stream()`
- `ToolCall` dataclass and `ToolCallOutput(Output)` in `lits/lm/base.py`
- `async-bedrock/` prefix in `get_lm()` factory
- `format_tool_result()` method on `AsyncBedrockChatModel` for provider-specific tool result messages
- `BaseToolUseStep` extracted from `ToolUseStep` (`lits/structures/tool_use.py`) — shared base for text-based and native tool use steps
- `NativeToolUseStep(BaseToolUseStep)` (`lits/structures/tool_use.py`) — step for native tool use with `assistant_message_dict` and `user_message`

### Changed
- `ToolUseTransition.step()` assert updated: `isinstance(step, BaseToolUseStep)` (accepts both ToolUseStep and NativeToolUseStep)
- `AsyncNativeToolUsePolicy` (`lits/components/policy/native_tool_use.py`) — policy using native tool use API with structured tool calls

## 2026-04-10 - 04-15  0.4.0 (`0316-major-interleaved-expand`)

### Added
- `existing_siblings` parameter to `Policy.get_actions()` / `_get_actions()` for sibling-aware expansion
- `_interleaved_expand()` helper in `common.py` — sample → transition → repeat loop with full Step siblings
- `_do_expand()`, `_do_simulate()`, `_do_backpropagate()` override methods in `MCTSSearch`
- `_do_expand()` override method in `BFSSearch`
- `SiblingAwareMCTSSearch` registered as `mcts_sibling_aware` search method
- `SiblingAwareBFSSearch` registered as `bfs_sibling_aware` search method
- Query-level resume in `run_tree_search()` — skip examples with existing `terminal_nodes`
- `eval_idx` now respects `offset`/`limit` via `_slice_dataset`
- `_simulate()` accepts `expand_func` param for custom expand during rollout

### Fixed
- `_do_simulate()` signature — positional args aligned with module-level `_simulate()`
- `--cfg` and `--dataset-arg` now use `_AppendList` — repeated flags accumulate instead of replacing
- Sibling-aware `_do_expand` falls back to `self.reward_model` when continuation passes `reward_model=None`
- Sibling-aware `_do_expand` skips interleaved for `from_phase="continuation"` (preserves BN-SC agreement)
- `docs/agents/tree/mcts/MCTS_SEARCH_LOOP.md` — safeguard analysis, extension guide, memory coupling

## 2026-04-06 0.4.0 (`0302-agentbench-integration`)

### Added
- `docs/log/EXECUTION_LOG.md`: execution log monitoring guide (tree viz, node flags, progress tracking)

### Fixed
- `cli/search.py`: `resolve_answer` crash on tree search terminal nodes — `node["state"]` is a dict with `"steps"` key, not a list
- `cli/search.py`: `resolve_answer` now also updates `node.step.answer` (eval reads this first, was returning unresolved `#N`)

## 2026-04-05 0.4.0 (`x-0405-minor-mcts-tree-log`)

### Added
- `lits/visualize.py`: runtime ASCII tree renderer (`visualize_tree`, `_format_action`)

### Changed
- `lits/agents/tree/mcts.py`: tree snapshot at INFO level after each iteration and early termination
- `lits/agents/tree/bfs.py`: tree snapshot at INFO level after each depth layer

## 2026-04-05 0.4.0 (`x-0405-major-bn-evaluator-refactor`)

### Added
- `components/bn_evaluator/base.py`: `BNEvaluatorBase` ABC with `evaluate()` and `state_verbalizer`
- `components/bn_evaluator/exact_match_sc.py`: `ExactMatchSC` — no-LLM majority vote evaluator
- `components/bn_evaluator/bn_evaluator_qa.py`: `DirectLLM`, `LLMSemanticSC`, `EntropySC` subclasses
- `docs/components/bn_evaluator/BN_EVALUATOR.md`
- `unit_test/cit/test_bn_evaluator.py`

### Changed
- `components/bn_evaluator/bn_evaluator_env.py`: `BNEvaluatorEnv` inherits `BNEvaluatorBase`
- `components/factory.py`: `create_bn_evaluator` dispatches directly to new classes, supports `bn_method=sc_exact`
- `cli/search.py`: `BNEvaluator` type hint → `BNEvaluatorBase`

### Removed
- `components/bn_evaluator/bn_evaluator_qa.py`: monolithic `BNEvaluator` wrapper class

## 2026-04-05 0.4.0 (`x-0404-0405-minor-general-evaluator-float-score`)

### Added
- `eval/general_eval.py`: `output_type="float"` on `EvalPerspective` for 0.0–1.0 LLM scoring
- `eval/general_eval.py`: `check_score(pred, truth) -> float` convenience method
- `cli/eval_search.py`: `--llm-eval` unified CLI flag (`binary`/`f1`/`none`) for LLM fallback evaluator mode
- `cli/__init__.py`: `log_command(logger)` helper — logs `sys.argv` and `os.getcwd()` for reproducibility
- `cli/chain.py`, `cli/search.py`, `cli/eval_search.py`: `log_command` wired into all CLI entry points

### Changed
- `cli/eval_search.py`: modularized LLM fallback into `_llm_fallback()` helper
- `eval/general_eval.py`: better error messages — raw LLM output included in RuntimeError

### Fixed
- `cli/search.py`: `eval_idx` double-filter bug — dataset was filtered then loop re-filtered by index, skipping all examples

### Changed
- `cli/eval_search.py`: modularized LLM fallback into `_llm_fallback()` helper
- `eval/general_eval.py`: better error messages — raw LLM output included in RuntimeError

## 2026-04-04 0.4.0 (`0302-agentbench-integration`)

### Added
- `demos/lits_benchmark/kgqa_tools.py`: `KGState`, 7 BaseTool wrappers, `create_kg_tools()` factory
- `demos/lits_benchmark/kgqa.py`: `prepare_tool_state` callback in `@register_resource("kgqa")` for per-example tool state reset
- `demos/lits_benchmark/kgqa.py`: `resolve_answer` callback for post-run variable→entity resolution via SPARQL
- `docs/cli/protocol.md`: CLI–Registry protocol doc (dataset, resource, evaluator contracts + stateful tools)
- `unit_test/tools/test_kgqa_tools.py`: KG tool wrappers test against live SPARQL endpoint

### Changed
- `demos/lits_benchmark/kgqa.py`: dataset loader now formats complete query string (`Question: ...\nEntities: [...]`)
- `demos/lits_benchmark/kgqa.py`: `KGQA_SYSTEM_PROMPT` uses `<answer>` tags instead of `Final Answer:` format
- `demos/lits_benchmark/kgqa.py`: gold answer includes both entity names and Freebase IDs for F1 matching
- `demos/lits_benchmark/kgqa.py`: `resolve_answer` asserts `TrajectoryState` type for consistent contract
- `cli/chain.py`: `_run_tool_use` calls `prepare_tool_state` and `resolve_answer` per-example if provided by resource
- `cli/chain.py`: `max_steps` config now wired to `create_tool_use_agent(max_iter=...)`
- `cli/search.py`: per-example `prepare_tool_state` and `resolve_answer` support; deserializes dicts to `ToolUseState` before calling `resolve_answer`
- `cli/chain.py`, `cli/search.py`: default model updated to `bedrock/us.anthropic.claude-sonnet-4-6`

### Fixed
- `structures/tool_use.py`: `from_dict` now respects saved `answer` field over re-extracted value from `assistant_message`

## 2026-03-31 0.4.0 (`0302-agentbench-integration`, `x-0331-minor-transition-pre-step-hook`)

### Added
- `demos/lits_benchmark/kgqa.py`: `@register_dataset("kgqa")` loader for AgentBench KG (150 GrailQA examples)
- `demos/lits_benchmark/kgqa.py`: `@register_evaluator("kgqa")` returning set-based F1 (float 0.0–1.0)
- `demos/lits_benchmark/kgqa.py`: `KGQA_SYSTEM_PROMPT`, `build_one_shot_steps()`, `ONE_SHOT_QUESTION`
- `demos/lits_benchmark/kgqa.py`: `@register_resource("kgqa")` skeleton (tools placeholder)
- `cli/eval_search.py`: continuous score support — evaluators returning float tracked in `eval_scores`, reports Mean Score
- `tools/base.py`: `BaseTool.pre_step(state)` optional hook called before each tool execution
- `components/transition/tool_use.py`: `pre_step` wiring — calls `tool.pre_step(state)` on all tools before `execute_tool_action()`

## 2026-03-29 0.4.0 (`0312-major-context-augmentation`)

### Added
- `agents/tree/base.py`: `early_stop_reward` field on `BaseSearchConfig`
- `agents/tree/mcts.py`: reward threshold check in `terminate_on_first_solution` block

### Fixed
- `cli/eval_search.py`: checkpoint/terminal_node files now sorted numerically (was lexicographic, causing `10.json` before `2.json`)
- `cli/eval_search.py`: `[X]` in eval log now shows dataset query index (was sequential enumerate index)

## 2026-03-28 0.4.0 (`0328-minor-react-dbbench`)

### Added
- `cli/chain.py`: tool-use support via `ReActChat` (auto-detected by `has_resource()`)
- `agents/base.py`: `root_dir` and `eval_model_name` fields on `BaseConfig`
- `cli/eval_search.py`: chain checkpoint fallback — reads `checkpoints/` as `ToolUseState` when `terminal_nodes/` absent

### Fixed
- `agents/main.py`: removed stale `reasoning_method` kwarg from `ReactChatConfig` construction
- `agents/main.py`: fixed `task_type` → `task_name` kwarg in `ReActChat` construction
- `components/transition/tool_use.py`: no-action/no-answer steps appended to wrong state object (old vs copy)
- `cli/eval_search.py`: tool-use evaluation now passes `dataset_kwargs` to `load_dataset()`

## 2026-03-28 0.4.0 (`0312-major-context-augmentation`, Task 5/8)

### Added
- `lm/base.py`: `InferenceLogger.get_last_record()`, `cached` field on `update_usage()`
- `reward/tool_use.py`: cache hit logging with original token counts and `cached=True`
- `eval/general_eval.py`: `GeneralEvaluator.check_correct()` convenience method
- `cli/eval_search.py`: LLM-based evaluation fallback for tool-use tasks via `GeneralEvaluator`

### Fixed
- `eval/general_eval.py`: re-raise auth/credential errors instead of silently returning `out_of_context`
- `bedrock_chat.py`: skip `top_p` for Sonnet 4.6/4.5 (`ValidationException`)
- `cli/args.py`: `--var` now uses `_AppendList` so repeated flags accumulate (was silently overwriting)

### Changed
- `cli/eval_search.py`: evaluation priority now includes LLM judge for tool-use verbose answers

## 2026-03-27 0.4.0 (`0327-minor-semantic-diversity`)

### Added
- `eval/llm_call_logger.py`: `cluster_by_embedding()` — embedding-based candidate grouping with union-find
- `eval/llm_call_logger.py`: `judge_semantic_equivalence()` — LLM judge for semantic equivalence
- `eval/llm_call_logger.py`: `_apply_semantic_dedup()` — two-stage pipeline integration
- `eval/llm_call_logger.py`: `make_crosswords_correctness_checker()` — task-agnostic correctness predicate
- `eval/llm_call_logger.py`: `semantic_dedup` parameter on `get_diversity_stats()` and `print_diversity_report()`
- `cli/search.py`: auto-enable `semantic_dedup` for `language_grounded` tasks

### Changed
- `eval/llm_call_logger.py`: `correct_actions: Dict` → `is_correct: Callable[[str], bool]`
- `cli/search.py`: updated crosswords caller to use `make_crosswords_correctness_checker()`

## 2026-03-26 0.4.0 (`0312-major-context-augmentation`, Task 5/8)

### Fixed
- `eval/results.py`: circular import `eval→agents→components→eval` — lazy import `SearchNode` via `_get_search_node_class()` + `from __future__ import annotations`
- `cli/search.py`: missing `Dict` import (was resolved transitively before circular import fix)
- `cli/search.py`: HF login crash on expired token — wrapped in try/except (non-fatal for non-HF models)
- `bedrock_chat.py`: Sonnet 4.6/4.5 reject `temperature` + `top_p` together — skip `top_p` for newer models
- `fact_memory.py`: `record_action()` missing `query_idx` — memory LLM calls not attributed to instances in inference report
- `fact_memory.py`: `record_action()` missing `metadata.from_phase` — memory LLM calls not attributed to search phases
- `mcts.py`: `on_trajectory_complete` not called for terminal nodes found after expand/continuation/world_modeling — only fired after simulate

### Added
- `cli/args.py`: `--root-dir` CLI flag — prepends custom root to auto-generated result path
- `config.py`: `root_dir` field on `ExperimentConfig`, wired into `setup_directories()`
- `mcts.py`: iteration number in log (`[MCTS] Iteration 0/30 (example=0)`), `from_phase` in Expand Begin/End logs
- `mcts.py`: `from_phase` passed through `on_step_complete` and `on_trajectory_complete` callbacks
- `sql_error_profiler.py`, `sql_validator.py`: `from_phase` forwarded to `_call_model()` for inference logging
- `lm/base.py`: `InferenceLogger.get_last_record()` method, `cached` field on `update_usage()`
- `reward/tool_use.py`: `ToolUsePRM` logs cache hits in inference logger with original token counts and `cached=True`

### Changed
- `cli/search.py`: removed dead `memory_manager` param from `run_tree_search()` (only `augmentors` passed now)
- `search_base.py`: removed `memory_manager` param from `BaseTreeSearch.__init__`
- `bedrock_chat.py`: Sonnet 4.6/4.5 reject `temperature` + `top_p` together — skip `top_p` for newer models
- `fact_memory.py`: `record_action()` missing `query_idx` — memory LLM calls not attributed to instances in inference report
- `fact_memory.py`: `record_action()` missing `metadata.from_phase` — memory LLM calls not attributed to search phases
- `mcts.py`: `on_trajectory_complete` not called for terminal nodes found after expand/continuation/world_modeling — only fired after simulate

### Added
- `cli/args.py`: `--root-dir` CLI flag — prepends custom root to auto-generated result path
- `config.py`: `root_dir` field on `ExperimentConfig`, wired into `setup_directories()`
- `mcts.py`: iteration number in log (`[MCTS] Iteration 0/30 (example=0)`), `from_phase` in Expand Begin/End logs
- `mcts.py`: `from_phase` passed through `on_step_complete` and `on_trajectory_complete` callbacks
- `sql_error_profiler.py`, `sql_validator.py`: `from_phase` forwarded to `_call_model()` for inference logging

### Changed
- `cli/search.py`: removed dead `memory_manager` param from `run_tree_search()` (only `augmentors` passed now)
- `search_base.py`: removed `memory_manager` param from `BaseTreeSearch.__init__`

## 2026-03-22 - 2026-03-25 0.4.0 (`0312-major-context-augmentation`, Task 5)

### Fixed
- `augmentor_setup.py`: `on_step_complete`/`on_trajectory_complete` call `aug.analyze()` instead of `aug.evaluate()` — fixes `FactMemoryAugmentor` crash (`_analyze()` not implemented)
- `mcts.py`: `_combined_retrieve()` closure now sees current `trajectory_key` — `augmentor_query_context` dict mutated by `update_traj_key()` before each `_expand()`
- `common.py::_sample_actions_with_existing`: preserve expand-phase children during simulate truncation
- `mcts.py`: `augmentor_query_context` missing `query_idx` — `_combined_retrieve()` constructed wrong `search_id`, causing empty memory retrieval
- `fact_memory.py`: assert `query_idx is not None` in `analyze()`/`retrieve()` to fail loudly on missing `query_idx`

### Added
- `augmentor_setup.py`: INFO-level `[Memory]` logging in `_combined_retrieve()` (traj_key, result length)
- `fact_memory.py`: INFO-level `[Memory]` logging in `retrieve()` (search_id, inherited count, retrieved_trajs count)
- `retrieval.py`: INFO-level `[Memory]` logging in `TrajectorySearchEngine.search()` (per-candidate score vs threshold, missing_units count)
- `docs/memory/TRAJECTORY_SEARCH_ENGINE.md` — architecture diagram, data flow, and case study
- `docs/components/callback.md` — FAQ on single `[Memory] retrieve` per expand

### Changed
- `base.py::Policy._get_dynamic_notes()`: "You MUST AVOID the following mistakes:" → neutral "Additional Notes:" prefix
- `cli/search.py`: wire `FactMemoryAugmentor` into `augmentors` list when `memory_manager` is created; pass `augmentors` through `run_tree_search` to searcher

### Fixed
- `test_fact_memory_mcts.py`: `MemoryUnit` attribute errors (`trajectory_key` → `origin_path`, `content` → `text`)

## 2026-03-21 0.4.0 (`0312-major-context-augmentation`, Task 5)

### Added
- `lits/agents/tree/augmentor_setup.py`: `setup_augmentors()` callback wiring for tree search
- `on_step_complete` callback param in `_expand()` and `_simulate()`
- `on_trajectory_complete` callback in `MCTSSearch.search()` after backpropagation
- `augmentors` param on `BaseTreeSearch.__init__()`
- Augmentor buffer flush in `BaseTreeSearch._teardown()`

### Removed
- Hardcoded "Memory Context Retrieval" and "Memory Recording" blocks from `MCTSSearch.search()`
- `memory_context` param from `_expand()`, `_sample_actions_with_existing()`, `Policy.get_actions()`
- `_current_memory_context` / `_format_memory_context()` from `Policy`

## 2026-03-21 0.4.0 (`0312-major-context-augmentation`, inference-logging)

### Changed
- `setup_inference_logging()` in `lits/lm/loader.py`: positional model params → `*models` varargs with `LanguageModel` type check
- `lits/cli/search.py`: memory_llm (via `backend._llm`) included in `setup_inference_logging` call
- `lits/cli/chain.py`: migrated `setup_inference_logging` call to keyword-only style

## 2026-03-21 0.4.0 (`x-0316-0321-major-local-memory-backend`)

### Added
- `--memory-arg` CLI flag in `lits/cli/args.py` with `parse_memory_args()` parser
- `_create_local_backend()` / `_create_mem0_backend()` factory helpers in `lits/cli/search.py`
- `memory_args` field on `ExperimentConfig` (`lits/config.py`)
- CLI usage and case study sections in `docs/memory/LOCAL_MEMORY_BACKEND.md`

### Changed
- `setup_memory_manager()` in `lits/cli/search.py`: rewrote to use `parse_memory_args()` with `backend=local|mem0` routing
- `to_prompt_blocks()` heading: "Inherited memories" → "Known facts from your current reasoning"
- `TrajectorySimilarity.to_prompt_section()` heading: "Trajectory q/..." → "Insights from a previous attempt"

### Deprecated
- `ExperimentConfig.memory_config` field (use `memory_args` instead)

## 2026-03-20 0.4.0 (`x-0316-0320-minor-embedding-subpackage`)

### Added
- `lits/embedding/` subpackage: `BaseEmbedder` ABC, `SentenceTransformerEmbedder`, `BedrockEmbedder`, `get_embedder()` factory
- `docs/embedding/EMBEDDING.md`

### Changed
- `LocalMemoryBackend`: eager embedder init (was lazy); accepts `embedder: BaseEmbedder`
- `PDFClient` uses `get_embedder()` instead of direct `SentenceTransformer`
- `PDFClient` uses `get_embedder()` instead of direct `SentenceTransformer`

## 2026-03-16 0.4.0 (`x-0316-0321-major-local-memory-backend`)

### Added
- `LocalMemoryBackend` in `lits/memory/backends.py` — in-memory backend with LLM fact extraction and embedding-based semantic dedup
- `LocalMemoryBackend.save(dir)` / `load(dir)` persistence (jsonl + npz)
- `_parse_facts_response()` helper for JSON/line-split fallback parsing (`lits/memory/backends.py`)
- Length-heuristic update in `LocalMemoryBackend`: if new fact is >1.3× longer than matched existing, replaces in-place
- `"memory"` role prefix for InferenceLogger token tracking of memory LLM calls (`lits/lm/base.py`, `lits/components/utils.py`)
- `query_idx` parameter on `record_action()` / `add_messages()` for per-instance attribution

### Changed
- `LiTSMemoryManager.record_action()`: removed unused `facts` parameter; `messages` is now required
- `LiTSMemoryManager.record_action()`: removed `metadata_for()` call; metadata passed through directly
- `LiTSMemoryManager`: removed `_cache`, `_cache_dirty`, `_ensure_cache()` — caching now lives in backends
- `LiTSMemoryManager.record_action()`: removed cache maintenance; delegates entirely to backend
- `LiTSMemoryManager.list_inherited_units()` / `search_related_trajectories()`: call `backend.list_all_units()` directly
- `LocalMemoryBackend._add_facts()`: reads trajectory info from `TrajectoryKey` directly instead of metadata dict
- `LocalMemoryBackend._add_facts()`: cross-trajectory alias never mutates matched unit (trajectory isolation)
- `LocalMemoryBackend._add_facts()`: extracted `_update_unit()` helper for in-place update
- `LocalMemoryBackend._add_facts()`: in-place updates excluded from return value
- `Mem0MemoryBackend.add_messages()`: constructs qdrant payload metadata from `TrajectoryKey` internally
- `FactMemoryAugmentor`: removed unused `_buffer` usage and simplified `flush_buffer()` to no-op
- `FactMemoryAugmentor` docstring: updated to reference `LocalMemoryBackend` instead of mem0
- mcts.py `record_action()`: removed redundant `trajectory_path`/`trajectory_depth`/`ancestry_paths` from metadata

### Removed
- `LiTSMemoryConfig.metadata_for()` and `_metadata_defaults` (`lits/memory/config.py`)

## 2026-03-16 0.4.0 (`0312-major-context-augmentation`)

### Added
- `TrajectoryState.__init__(steps=None, **kwargs)` supporting list-based construction (`lits/structures/base.py`)
- `ReflectionAugmentor` in `lits/components/context_augmentor/reflection.py`
- `LATS_REFLECTION_PROMPTS` dict with `hotpotqa`, `webshop`, `humaneval` keys (`reflection.py`)
- `flush_threshold` param on `ContextAugmentor.__init__` (0 = no auto-flush)
- Buffer accumulation + auto-flush in ABC `ContextAugmentor.analyze()`
- `set_storage_context(policy_model_name, task_type)` on `ContextAugmentor` ABC
- `FactMemoryAugmentor` in `lits/components/context_augmentor/fact_memory.py`

### Changed
- `analyze(traj_state)` is now mandatory (no `None` default) on `ContextAugmentor` ABC
- `SQLValidator._analyze()` expects trajectory/list, extracts `traj_state[-1]`

### Fixed
- `test_sql_validator.py`: `traj_state=step` → `traj_state=[step]` in sections 3, 4, 7
- `test_state_serialization.py`: fixed `serialized` dict iteration bugs

## 2026-03-15 0.4.0 (`0312-major-context-augmentation`)

### Added
- `ContextAugmentor` ABC and `ContextUnit` dataclass in `lits/components/context_augmentor/__init__.py`
- `require_chat_model` param on `ContextAugmentor.__init__`
- `sql_validator.py` and `sql_error_profiler.py` in `lits/components/context_augmentor/`
- `normalize_trajectory_key()` in `lits/memory/types.py`
- `CriticAugmentor` in `lits/components/context_augmentor/critic.py` with `task_type` support (`language_grounded`, `tool_use`)
- `_call_model()` helper on `ContextAugmentor` ABC with `"augmentor"` role for InferenceLogger cost attribution (`lits/components/context_augmentor/__init__.py`, `lits/components/utils.py`)

### Changed
- `SQLValidator` and `SQLErrorProfiler` now inherit directly from `ContextAugmentor`
- `docs/components/verbal_evaluator/` → `docs/components/context_augmentor/`
- `docs/agents/LEARNING_LOOP.md` → `docs/components/context_augmentor/LEARNING_LOOP.md`
- `SQLValidator._validate()` and `SQLErrorProfiler._analyze()` use `_call_model()` instead of `role=None`
- `CriticAugmentor._analyze()` uses `_call_model()` instead of direct `create_role("dynamics_critic", ...)`

### Fixed
- `evaluator_type` class attribute on subclasses (e.g. `CriticAugmentor.evaluator_type = "critic"`) no longer overwritten by ABC `__init__`

### Removed
- `generate_critic()` from `ConcatTransition`
- `use_critic` from `MCTSConfig`, `_expand`, `_simulate`, `_continuation`, `_sample_actions_with_existing`, `config.py`
- `critic=` parameter from `Policy.get_actions()`, `Policy._get_actions()`, `ConcatPolicy`, `ToolUsePolicy`
- `analyze()` uses `trajectory_key` kwarg (not `query_idx`) for `ContextUnit.trajectory_key`
- `ContextUnit.trajectory_key` docstring updated to `q/0/1/3` format
- Storage path `~/.lits_llm/verbal_evaluator/` → `~/.lits_llm/context_augmentor/`

### Fixed
- `_filter_by_history_access`: `cross_step` now matches both `trajectory_key` AND `query_id` to prevent cross-task leakage

### Removed
- `lits/components/verbal_evaluator/` subpackage (no backward-compat shim)
- `VerbalEvaluator` class (`verbal_evaluator/base.py`)

## 2026-03-13 0.4.0 (`x-0313-major-backprop-modes`)

### Added
- `_back_propagate_decay()` in `lits/agents/tree/mcts.py`
- `backprop_mode` and `decay_gamma` fields in `MCTSConfig`
- `backprop_broadcast_mode` (`per_node`/`terminal`) in `MCTSConfig`
- `visit_count` on `MCTSNode` (`lits/agents/tree/node.py`)
- `docs/agents/tree/common/BACKPROPAGATION.md`

### Changed
- `_uct_select` uses `visit_count` with fallback to `len(cum_rewards)`
- `_back_propagate` and `_back_propagate_decay` support `broadcast_mode` parameter
- Renamed `cum_reward` → `backprop_reward_func` in `MCTSConfig`
- Renamed `calc_q` → `cross_rollout_q_func` in `MCTSConfig` and `MCTSNode`
- Renamed `set_default_calc_q` → `set_default_q_func` in `MCTSNode`
- `_back_propagate` terminal mode: append raw terminal reward instead of running average

## 2026-03-12 0.4.0 (`0304-major-lats-reward-refactor`)

### Added
- `transition_before_evaluate` flag in `MCTSConfig` (`lits/agents/tree/mcts.py`)
- `_world_modeling` per-child path in `_expand()` when `transition_before_evaluate=True`
- `RewardModel.requires_transition_before_evaluate` property (`lits/components/base.py`)
- Auto-inference of `transition_before_evaluate` in `MCTSSearch._setup()` (`lits/agents/tree/mcts.py`)

### Changed
- `ToolUsePRM._fast_reward()` refactored to direct scoring mode (`max_rollout_steps=0` default) (`lits/components/reward/tool_use.py`)
- `max_eval_rollout_steps` default from 5 to 0 in `create_components_tool_use()` (`lits/components/factory.py`)
- Renamed "Stateless LM Scoring" → "Direct LM Scoring" in `ToolUsePRM` (`lits/components/reward/tool_use.py`)
- Updated `docs/components/reward/TOOL_USE_PRM.md`
- Updated `docs/LITS_DESIGN.md` Section 3.1 task type comparison

## 2026-03-10 0.4.0 (`x-0310-minor-register-evaluator`)

### Added
- `register_evaluator` / `get_evaluator` / `has_evaluator` in `BenchmarkRegistry` (`lits/benchmarks/registry.py`)
- `@register_evaluator("dbbench")` for DBBench evaluation (`demos/lits_benchmark/dbbench.py`)
- `docs/eval/CUSTOM_EVALUATORS.md`

### Changed
- `lits-eval` accuracy loop uses registered evaluator when available (`lits/cli/eval_search.py`)

## 2026-03-09 0.4.0

### Changed
- Registry-based search config creation; moved MCTS defaults into `MCTSConfig` (`x-minor-register-search-decorator`)

## 2026-03-01 0.4.0
### Added
- Save layer-wise checkpoint in bfs
- Added docs/TRAJ_CHECKPOINT.md

## 2026-02-28 0.3.2

### Added
- Groq auto-configuration in `get_lm()` — `groq/` prefix auto-sets `base_url` and reads `GROQ_API_KEY` (`lits/lm/__init__.py`)
- `LITS_LOG_LEVEL` env var for console log level (`lits/log.py`)

### Changed
- README Quick Start rewritten: zero-clone math demo with `@register_dataset` + `--include` (`README.md`)
- README: added LLM provider config section (OpenAI, Bedrock, Groq, HuggingFace, vLLM/OpenAI-compatible)
- README: added demo video link and restructured CLI examples as video companion
- OpenAI unsupported kwargs warnings downgraded to `logger.debug` (`lits/lm/openai_chat.py`)
- Bedrock API call params and extra kwargs warnings downgraded to `logger.debug` (`lits/lm/bedrock_chat.py`)
- LLM call diversity report moved from `print` to `logger.info` (`lits/eval/llm_call_logger.py`)

### Fixed
- `GenerativePRM` logits fallback crash when backend doesn't support logits (`lits/components/reward/generative.py`)

### Docs
- vLLM/Qwen3 caveats for AWQ, thinking mode, and version conflicts (`docs/CAVEAT.md`)

## 2026-02-22 0.3.2 (ThinkPRM TGI Support)

### Changed
- `ThinkPRM` now uses `base_model` from `--eval-model` instead of creating its own TGI/SageMaker wrapper (`lits/components/reward/thinkprm.py`)
- Deleted `ThinkPRMTGI` wrapper class - functionality moved to `ThinkPRM`

### Added
- Import `ThinkPRM` in `factory.py` to trigger `@register_reward_model` decorator (`lits/components/factory.py`)

### Fixed
- `ThinkPRM` now properly passes `base_model` to parent `RewardModel` class

## 2026-02-22 0.3.2 (Eval CLI Improvements)

### Fixed
- `ThoughtStep.to_dict()` now includes `action` field for proper serialization (`lits/structures/qa.py`)
- `extract_answers_from_terminal_nodes` falls back to `node.action` when state is empty (`lits/agents/tree/common.py`)

### Changed
- `lits-eval` now shows progress bar + concise summary by default (`lits/cli/eval_search.py`)
- Added `-v`/`--verbose` flag for detailed console output
- Detailed logs saved to `eval.log` in result directory

### Docs
- Added `lits-eval` usage section to `docs/CAVEAT.md`

## 2026-02-22 0.3.2 (ExperimentConfig Serialization)

### Added
- `ExperimentConfig.to_dict()` and `save_config()` methods (`lits/config.py`)
- `import_modules` and `dataset_kwargs` as top-level fields in `ExperimentConfig`
- `max_new_tokens` in `_DEFAULT_COMPONENT_ARGS` (`lits/config.py`)

### Changed
- `cli/search.py` uses `config.save_config()` instead of `search_config.save_config()`
- `cli/eval_search.py` reads `import_modules`/`dataset_kwargs` from top-level config

## 2026-02-21 0.3.2 (Tree Search Log Metadata)

### Fixed
- `config.json` now saves `policy_model_name`, `eval_model_name`, `dataset`, `output_dir` (`lits/config.py`)

### Added
- `set_log_field()` method in `BaseTreeSearch` (`lits/agents/tree/search_base.py`)
- `on_step` callback parameter in `_continuation()` (`lits/agents/tree/continuation.py`)
- `on_step` callback parameter in `_simulate()` (`lits/agents/tree/mcts.py`)
- `get_metrics_by_depth()` method in `InferenceLogger` (`lits/lm/base.py`)
- Tree metadata logging: `iteration` and `trajectory_key` fields in inference logs

## 2026-02-18 v0.3.1

### Added
- PyPI publish workflow (`.github/workflows/publish.yml`)

### Fixed
- `lits/cli/chain.py`: remove stale `reasoning_method` kwarg from `EnvChainConfig`
- `README.md`: correct Python API imports (`MCTSConfig` instead of `BaseSearchConfig`)
- `pyproject.toml`: fix project URLs to point to `lits-llm` repo

### Changed
- Bump version to 0.3.1

## 2026-02-16 v0.2.11 (Inference Report Improvements and Dry-run Fix)

- inference_report.py: add Cost to BY INSTANCE; auto-hide zero Time columns
- eval_search.py: add --input-price/--output-price CLI args; print eval log path
- search.py: skip load_resource() in --dry-run mode for tool-use tasks

## 2026-02-15 v0.2.11

### Changed
- Lazy-import `transformers`/`torch`/`numpy`/`huggingface_hub` in `lits/lm/base.py` and `lits/lm/__init__.py`

### Changed (See .kiro/specs/x-minor-chain-result-dir)
- Consolidate result directory logic: `get_model_dir_prefix()` and `MODEL_NAME_TO_DIR_PREFIX` in `lits/agents/base.py`
- `BaseConfig.setup_directories(run_id)` (`lits/agents/base.py`)
- Remove standalone `get_result_dir()` from `lits/cli/chain.py`
- `ExperimentConfig.get_result_dir()` uses shared `get_model_dir_prefix()`

### Added (See .kiro/specs/minor-output-dir-cli)
- `--output-dir` / `-o` CLI flag (`lits/cli/args.py`)
- `output_dir` field on `BaseConfig` and `ExperimentConfig`
- `output_dir` override in `BaseConfig.setup_directories()` and `ExperimentConfig.setup_directories()`

## 2026-02-14  v0.2.11 (Too-Use Registry)

### Fixed
- `lits_benchmark/mapeval.py`: inline dataset loading (fix broken `_load_mapeval_examples` call)
- `lits/benchmarks/registry.py`: remove stale `"examples"` references from `@register_resource` docstrings
- `unit_test/search/test_mcts_tool_use_integration.py`: use `load_dataset()` instead of `tool_use_spec["examples"]`
- `unit_test/components/test_benchmark_registry.py`: import modules in `setUpClass` instead of removed fallbacks
- `unit_test/components/test_auto_registration.py`: remove stale `mapeval` (non-sql) from docstring

### Removed
- `load_resource`/`load_dataset_examples` from `lits_benchmark/__init__.py`


## 2026-02-13 v0.2.11  (Too-Use Registry)
### Added
- `@register_resource` decorator for tool-use benchmarks (`lits/benchmarks/registry.py`)

## 2026-02-12 v0.2.10 (CLI Commands)
### Added
- `lits-search`, `lits-eval`, `lits-chain`, `lits-eval-chain` CLI entry points (`pyproject.toml`)
- `lits/cli/search.py` — tree search entry point
- `lits/cli/eval_search.py` — tree search evaluation entry point
- `lits/cli/chain.py` — chain agent entry point
- `lits/cli/eval_chain.py` — chain agent evaluation entry point

### Changed
- `examples/` scripts converted to thin backward-compat wrappers

### Removed
- `lits/cli/commands.py` placeholder stubs

## 2026-02-11 v0.2.9 (BlocksWorld: From built-in to external)
### Changed
- Moved `BlocksWorldTransition` from `lits/components/transition/blocksworld.py` to `lits_benchmark/blocksworld.py`
- Moved BlocksWorld prompts (policy, reward, transition) to decorator-based registration in `lits_benchmark/blocksworld.py`

## 2026-02-09 v0.2.9 (Search Registry)
See details in `.kiro/specs/x-base-tree-search`

### Added
- `BaseTreeSearch` ABC and `SearchResult` dataclass (`lits/agents/tree/search_base.py`)
- `InferenceLogger.log_context()` for binding search-phase metadata to LLM call records
- `MCTSSearch` and `BFSSearch` classes inheriting from `BaseTreeSearch`
- `--policy`, `--transition`, `--reward` CLI flags wired through component factory
- `TrajectoryKey` to BFS root node (`lits/agents/tree/bfs.py`)
- Thinking mode support for `TGIChatModel` (Qwen3) (`lits/lm/tgi.py`)

### Changed
- `@register_search` now supports class-based registration (`lits/agents/registry.py`)
- Simplified `main_search.py`: unified `search_kwargs`, `algo_output.to_paths()`, single `TreeToJsonl`
- Updated `lits/agents/__init__.py` exports: `MCTSSearch`, `BFSSearch`, `BaseTreeSearch`, `SearchResult`
- `create_components_language_grounded` and `create_components_env_grounded` accept override params (`lits/components/factory.py`)
- `ExperimentConfig`: added `policy`, `transition`, `reward` override fields (`lits/config.py`)

### Fixed
- TGI `running_time`: prefer server-side `x-compute-time` over client wallclock (`lits/lm/tgi.py`)

### Docs
- Added `log_context()` section to `INFERENCE_LOGGER.md`

## 2026-02-08 v0.2.8
### Docs
- Split `CHAIN.md` into `ENV_CHAIN.md` and `ReAct.md` (`docs/agents/`)

## 2026-02-06 v0.2.8
### Fixed
- Bedrock support for Opus 4.5 (`lits/lm/base.py`)

## 2026-02-04 v0.2.8
### Changed
- Moved `examples/math_qa/main_cot.py` to `examples/main_cot.py`
- `main_cot.py`: added `--override` flag, fixed `sys.path` and `.env` path for new location
- `main_cot.py`: fixed `extract_numerical_answer` to clean up literal `""` responses
- `main_cot.py`: `process_model_output` always wraps in `<think>...</think>` for correct parsing
- `main_cot.py`: skip extraction call when solution is empty

### Fixed
- `_parse_value` in `lits/cli/args.py` now handles list syntax `[5]` or `[1,2,3]`

## 2026-02-02 v0.2.8
### Added
- `dataset_kwargs` saved to config.json by `main_search.py` for reproducible dataset loading
- `--dataset-arg levels=[5]` to all math500 examples in `run_configs.sh`
- `docs/cli/search.md` - CLI documentation for main_search.py and eval_search.py
- CLI argument parsing in `examples/math_qa/main_cot.py` (`--dataset`, `--model`, `--dataset-arg`)

### Changed
- `main_search.py` uses `load_dataset()` from registry for language_grounded tasks
- `eval_search.py` uses `load_dataset()` from registry for language_grounded tasks
- `eval_search.py` loads `dataset_kwargs` from config.json and passes to dataset loader
- Accuracy calculation uses `eval_output()` for numeric comparison instead of exact string match

### Fixed
- Dataset index mismatch in `eval_search.py`: `query_idx` now correctly indexes filtered dataset
- Bedrock empty response handling in `eval_output()`
- `_parse_value` in `lits/cli/args.py` now handles list syntax `[5]` or `[1,2,3]`

## 2026-02-01 v0.2.8
### Added
- `SubQAStep.to_dict()` and `from_dict()` for proper serialization (`lits_benchmark/formulations/rap/structures.py`)
- `--override` cleanup: removes stale files in `checkpoints/`, `terminal_nodes/`, and `treetojsonl*.jsonl` (`examples/main_search.py`)

### Changed
- `llm_calls.jsonl` logging now skipped for `language_grounded` tasks (only enabled for `env_grounded`/`tool_use` where duplicate detection is meaningful)
- Refactor logging ssystem (see .kiro/specs/logging-system-refactoring for details)

### Fixed
- RAP `_step` TypeError: extract action string from Step object (`lits_benchmark/formulations/rap/transition.py`)
- RAP `_fast_reward`: handle Step objects and access `SubQAStep.sub_question` instead of tuple unpacking (`lits_benchmark/formulations/rap/reward.py`)
- CLI `--search-arg` overwrite bug: multiple `--search-arg` flags overwrite instead of append due to `nargs="+"` (e.g., `--search-arg a=1 --search-arg b=2` keeps only `b=2`); fixed `run_configs.sh` and added `or` fallback for `None` values

## 2026-01-31 v0.2.8
### Added
- `TGIChatModel` for TGI's `/v1/chat/completions` endpoint (`lits/lm/tgi.py`)
- `tgi-chat://` URL prefix for chat models via TGI
- `TGIModel.is_chat_model` property using `infer_chat_model()`
- `TGIModel.get_next_token_logits()` using TGI grammar constraints (`lits/lm/tgi.py`)
- `TGIModel.get_top5_logits()` using TGI's `top_n_tokens` feature (`lits/lm/tgi.py`)

### Fixed
- RAP state type mismatch with `TrajectoryState` (`lits_benchmark/formulations/rap/policy.py`, `transition.py`)
- RAP `_generate_prompt` now handles `TGIModel`
- `TGIModel` stop parameter: convert string to list for TGI API (`lits/lm/tgi.py`)
- `TGIModel` error handling: include response body in 422 errors

### Changed
- Generic type parameters in base classes: `Generic[StateT, ActionT]` → `Generic[StateT, StepT]` (`lits/components/base.py`)

## 2026-01-29 v0.2.8 (Search Registry)
see .kiro/specs/register-search-decorator for details

### Added
- `AgentRegistry` and `@register_search` decorator for custom search algorithms (`lits/agents/registry.py`)

### Changed
- Unified search invocation in `main_search.py` using `AgentRegistry.get_search()`

## 2026-01-29 v0.2.8 (Codebase Refactoring for Language-Grounded Tasks)
See .kiro/specs/lang_grounded_refactoring for details

### Added
- `--policy-model`, `--eval-model`, `--transition-model`, `--bn-model` CLI flags (`lits/cli/args.py`)
- `--search-arg` and `--component-arg` CLI flags for parameter passing
- `--help-config` flag for parameter discovery
- `from_config()` pattern for components (`GenerativePRM`, `ThinkPRM`, `ConcatPolicy`, `ConcatTransition`)
- `TGIModel` class for remote TGI completion models (`lits/lm/tgi.py`)
- `Step.verbalize_state()` class method for extensible state verbalization
- RAP formulation as external module (`lits_benchmark/formulations/rap/`)
- `ComponentRegistry` for custom formulation registration

### Changed
- Refactored `ExperimentConfig` from ~50 fields to minimal ~15 fields (`lits/config.py`)
- Moved `ExperimentConfig` to `lits/config.py`
- Moved `component_factory.py` to `lits/components/factory.py`
- Moved `model_loader.py` to `lits/lm/loader.py`
- Renamed `terminal_gen_model_name` to `transition_model_name`
- Factory now uses registry-driven component lookup

### Removed
- `reasoning_method` from `BaseConfig`
- RAP components from core package (moved to `lits_benchmark/formulations/rap/`)


## 2026-01-22 v0.2.8

### Added
- `docs/agents/TREE_SEARCH_GUIDE.md`: FAQ section explaining MCTS termination behavior

## 2026-01-21  v0.2.8

### Added
- `create_llm_call_logger()` factory for incremental LLM call logging (`lits/eval/llm_call_logger.py`)
- `load_llm_calls()`, `get_diversity_stats()`, `print_diversity_report()` analysis functions
- `normalize_crosswords_action()`, `parse_crosswords_correct_actions()` for crosswords analysis
- LLM call logging integration in `main_search.py`

### Fixed
- `eval_search.py`: Sort terminal nodes by cumulative reward before selecting best for env_grounded tasks
- `main_search.py`: Map `--override` CLI flag to `config.override_log_result`

## 2026-01-20  v0.2.8

### Added
- `Step.terminate` field to signal fatal errors that should stop trajectory generation (`lits/structures/base.py`)
- `EnvGroundedPolicy._generate_action_with_retry()` with temperature escalation for duplicate action avoidance (`lits/components/policy/env_grounded.py`)
  - Note: BlocksWorld MCTS results were generated with `max_retries=1` without temperature-incremented re-generation
- `Policy.set_llm_call_fn()` callback for intercepting LLM calls (`lits/components/base.py`)

### Changed
- `EnvStep.from_dict()` deserializes `terminate` field (`lits/structures/env_grounded.py`)
- `EnvGroundedPolicy` fallback behavior: finite action space uses unselected valid action; infinite action space sets `terminate=True`
- `EnvChain.run()` now checks `step.terminate` to stop trajectory on fatal errors (`lits/agents/chain/env_chain.py`)
- `bfs._expand()` and `bfs._expand_with_existing()` check `step.terminate` to mark nodes as terminal (`lits/agents/tree/bfs.py`)
- `mcts._expand()` checks `step.terminate` to mark nodes as terminal (`lits/agents/tree/mcts.py`)

## 2026-01-19  v0.2.8
## Fixed
- `goal_check` was incorrectly parsing answers from Filled/Changed sections
      - Now extracts board from "Current Board:" section and computes 10 answers

## 2026-01-18  v0.2.8 (Config & CLI Refactoring)

### Added
- `BaseConfig`: `benchmark`, `import_modules`, `dataset_kwargs` fields for experiment metadata
- `ChainConfig`: `temperature` field (0.0 = deterministic)
- `lits/cli/args.py`: `parse_script_vars()` for `--var` arguments

### Changed
- CLI arguments refactored: `--cfg` for config fields, `--var` for script variables
- `apply_config_overrides()` uses `--cfg` args (field names match config exactly)
- `EnvChainConfig` simplified: removed `offset`, `limit`, `override`, `temperature` (moved to parents)
- `main_env_chain.py` uses new CLI pattern with `--cfg`/`--var`/`--dataset-arg`

### Removed
- `offset`, `limit`, `override` from config classes (now script-local variables)

## 2026-01-13  v0.2.8 (Crosswords Domain & Error-Annotated Checkpoints)

### Added
- `lits_benchmark/crosswords.py` - CrosswordsTransition with `@register_transition("crosswords")`
- `CrosswordsTransition.validate_action()` for infinite action space validation
- `load_crosswords()` dataset loader with `@register_dataset("crosswords")`
- Crosswords-specific prompts registered via `@register_system_prompt`/`@register_user_prompt`
- `lits/prompts/policy/env_grounded.py` - generic fallback policy prompt
- `lits/prompts/reward/env_grounded.py` - generic fallback reward prompts
- `EnvState.__repr__()` showing step count and truncated current state
- Error-annotated checkpoints: `EnvStep(action=invalid_action, error=error_msg)` preserved in trajectory

### Changed
- `EnvGroundedPolicy` now always returns a step (error step if validation fails)
- `EnvGroundedPolicy._get_actions()` refactored into helper methods for readability
- `env_chain.py` handles `step.error` uniformly: appends error step, saves checkpoint, breaks
- `EnvGroundedTransition.generate_actions()` now non-abstract, returns `[]` by default
- `component_factory.py` uses `getattr` for optional `generate_actions` and `validate_action`

### Action Space Contract
- Finite action space (BlocksWorld): `generate_actions` returns exhaustive list
- Infinite action space (Crosswords): `validate_action` validates LLM-generated actions

## 2026-01-11  v0.2.7 (Component Registry)

### Added
- `lits/components/registry.py` - ComponentRegistry with `register_transition`, `register_policy`, `register_reward_model` decorators
- `lits/benchmarks/registry.py` - BenchmarkRegistry with `register_dataset`, `load_dataset`, `infer_task_type`
- `lits/prompts/registry.py` - `register_system_prompt`, `register_user_prompt` decorators
- `lits/components/transition/env_grounded.py` - EnvGroundedTransition base class with abstract `goal_check`, `generate_actions` static methods
- `lits/registry.py` - unified import entry re-exporting all registry decorators and utilities
- `import_custom_modules()` and `load_config_from_result_dir()` CLI utilities in `lits/registry.py`
- `import_modules` field to `BaseSearchConfig` for persisting custom module imports

### Changed
- `BlocksWorldTransition` now extends `EnvGroundedTransition` with `@register_transition("blocksworld")`
- `lits_benchmark/blocksworld.py` - `load_blocksworld` registered with `@register_dataset("blocksworld")`
- `lits_benchmark/math_qa.py` - registered gsm8k, math500, spart_yn datasets
- `lits_benchmark/mapeval.py` - registered mapeval, mapeval-sql datasets
- `lits_benchmark/crosswords.py` - registered crosswords dataset (placeholder)
- `component_factory.py` - uses registry-first with fallback pattern for env_grounded components
- `main_search.py` - added `--import` arg, saves `import_modules` to config
- `main_env_chain.py` - added `--import`/`--benchmark` args, uses registry lookup
- `eval_search.py` - auto-loads `import_modules` from config, uses registry for env_grounded detection
- `eval_env_chain.py` - auto-loads `import_modules`/`benchmark` from config

### Removed
- `lits_benchmark/main.py` - consolidated into `lits/benchmarks/registry.py`

## 2026-01-04  v0.2.6 (Env-Grounded Task: Main Scripts)
### Added
- `lits_llm/examples/main_env_chain.py` - unified env-grounded chain agent runner
- `lits_llm/examples/eval_env_chain.py` - evaluation script for env-grounded chain results

### Changed
- Refactored `main_env_chain.py` to use consistent result directory structure (`{model}_results/{benchmark}_chain/run_{version}/`)

### Fixed
- `EnvChain.run()` now passes `init_state_str` as keyword argument to `world_model.init_state()`
- `EnvChain.run()` now calls `is_terminal(state, query_or_goals)` with correct argument order


## 2026-01-04  v0.2.6 (Inference Report Generation)
### Added
- `lits/eval/inference_report.py` with `generate_report()` for formatted inference usage reports
- `InferenceLogger` multi-group aggregation: `get_metrics_by_component()`, `get_metrics_by_phase()`, `get_metrics_by_instance()`, `get_metrics_by_component_and_phase()`
- `_get_grouped_metrics()` core reader for efficient single-pass aggregation
- `calculate_cost()` utility in `lits/lm/base.py`
- `docs/lm/INFERENCE_LOGGER.md` documentation

### Changed
- `print_metrics_for_mcts_phases()` and `print_metrics_for_all_role_prefixes()` now use single file read
- `eval_search.py` uses `generate_report()` instead of `report_metrics_from_dir()`

### Removed
- `report_metrics_from_dir()` from `lits/lm/base.py`

## 2026-01-02  v0.2.6 (Hide create_role from subclass implementations)
### Changed
- Added `_call_model()` helper to `Policy`, `RewardModel`, `LlmTransition` base classes
- Added `step()`/`_step()` and `is_terminal()`/`_is_terminal()` wrapper pattern to `LlmTransition`
- Added `_batch_call_model()` and `_sample_binary_output()` helpers to `LlmTransition`
- Updated Policy subclasses (`ConcatPolicy`, `RAPPolicy`, `ToolUsePolicy`, `EnvGroundedPolicy`) to use `_call_model()`
- Updated RewardModel subclasses (`RapPRM`, `GenerativePRM`, `SelfConsistencyRM`) to use `_call_model()` / `_call_model_logits()`
- Updated LlmTransition subclasses (`BlocksWorldTransition`, `RAPTransition`, `ConcatTransition`) to use `_step()` / `_is_terminal()`
- `ConcatTransition` now extends `LlmTransition` instead of `Transition`


## 2025-12-24 - 12-25  v0.2.6
- Memory-MCTS integration: See `.kiro/specs/lits-mem-mcts-integration` 

- AugmentedContext.to_prompt_blocks() default include_inherited=False (lits/memory/manager.py)
- `TrajectorySearchEngine` in `lits/memory/retrieval.py`
  - filters redundant ancestor trajectories when descendant is retrieved
  - skips candidate trajectories that are ancestors of current trajectory

## 2025-12-22  v0.2.5 (3-level fallback of Prompt Registry)
### Changed
- Refactored prompt registry: renamed `math_qa` to `language_grounded` as task_type
- `PromptRegistry.get()` and `get_usr()` now use 3-level fallback: task_name → TASK_TYPE → default
- `BlocksWorldTransition.TASK_TYPE` set to `None` to prevent generic prompt fallback
- Updated `Policy`, `RewardModel`, `LlmTransition` base classes to pass `TASK_TYPE` for prompt lookup
- Integrated `PROMPT_INJECTION_DESIGN.md` content into `LITS_DESIGN.md`

### Removed
- `lits_llm/docs/PROMPT_INJECTION_DESIGN.md` (merged into LITS_DESIGN.md)


## 2025-12-21 (Morning)  v0.2.5 (Evaluation for Env-Grounded Task: BlocksWorld)
### Added
- eval_search.py: BlocksWorld evaluation support with goal satisfaction checking
- eval_chain.py: Logging support via setup_logging with file output

### Changed
- eval_search.py: Updated docstring with BlocksWorld usage examples and multi-task support
- eval_chain.py: Added comprehensive docstring with usage examples


## 2025-12-20  v0.2.5 (CiT for Env-Grounded Task: BlocksWorld)
### Added
- `BNEvaluatorEnv` for environment-grounded tasks (`lits/components/bn_evaluator/bn_evaluator_env.py`)
- Added `terminate_on_first_solution` to `ExperimentConfig` with the change of MCTS

### Changed
- create_bn_evaluator now supports task_type parameter for env_grounded tasks (lits_benchmark/experiments/component_factory.py)
- EnvGroundedPolicy._get_actions supports allow_duplicates parameter (
env_grounded.py
)
- sample_actions_with_existing passes allow_duplicates=True during continuation phase (lits/agents/tree/common.py)

### Fixed
- Removed max_steps from `BlocksWorldTransition` and `BlocksWorldTransition` creation in `component_factory.py`.
- `EnvGroundedPolicy._get_actions`
  - Added retry limit (max 5) and numeric index parsing to prevent infinite LLM calls
  - Added fallback to first valid action when max retries exceeded


## 2025-12-19  v0.2.5 (Tree Search for Env-Grounded Task: BlocksWorld)
### Added

- Incremental checkpoint saving in MCTS (`lits/agents/tree/mcts.py`)

- `checkpoint_dir` parameter in `mcts()` function

- `override_checkpoint` parameter in `mcts()` function

### Changed

- Enhanced `_back_propagate()` docstring with detailed example (`lits/agents/tree/mcts.py`)



## 2025-12-17  v0.2.5 (Tree Search for Env-Grounded Task: BlocksWorld)

### Added
- `init_state_kwargs` parameter in MCTS and BFS tree search agents

  - Allows passing example-specific data to `Transition.init_state(**kwargs)`
  - Subclasses extract what they need (e.g., BlocksWorld extracts init_state_str)
  - Files: `lits/agents/tree/mcts.py`, `lits/agents/tree/bfs.py`

- Comprehensive docstrings for component base classes
  - Documented `init_state_kwargs` convention in Transition class
  - Documented `query_idx` and `from_phase` parameters in RewardModel._fast_reward
  - Includes example code showing `create_role()` usage for inference logging
  - File: `lits/components/base.py`

### Updated
- Updated `BlocksworldTransition.init_state`
  - Now accepts `**kwargs` and extracts `init_state_str` from example data
  - Follows the unified `init_state_kwargs` convention
  - File: `lits/components/transition/blocksworld.py`


### Refactor
- `EnvGroundedPRM._fast_reward` to use sampled binary outputs with `n_sample`
  - Relevant Change: `LanguageModel.sample_binary_output` with unknown token support and last-word matching 
- Renamed task_type param to task_name for prompt lookup in components
  - Relevant Change: Added TASK_TYPE class constant to Policy, RewardModel, LlmTransition

### Fixed
- PDDL file path resolution in load_blocksworld
  - Added automatic base_dir inference from `data_file` path
  - File: `lits_benchmark/blocksworld.py`


## 2025-12-13  v0.2.5
### Added
- **Evaluation**:
  - Created `examples/blocksworld/eval_chain.py` for evaluating BlocksWorld chain checkpoints.
  - Added `report_metrics_from_dir` in `lits/lm/base.py` for standardized inference metric reporting.
- **Chain Agents**:
  - Added `BaseChainAgent` in `lits/agents/chain/base.py` to provide common functionality for chain-based agents (ReAct, EnvChain).
  - Added `init_state` and `next_state` fields to `EnvState` and `EnvStep` respectively.
  - Added `__type__` field to `EnvState` serialization for correct polymorphic deserialization.

### Refactor
- **State Structure**:
  - Unified `EnvState` with `TrajectoryState` by making `EnvState` inherit from `TrajectoryState`.
  - Integrated `env_state`, `last_env_state`, `step_idx` logic into `EnvState` properties, removing redundant fields.
  - Promoted `render_history` and `to_messages` from `ToolUseState` to `TrajectoryState` base class for shared usage.
  - Removed `StepConcatState` from `lits/structures/qa.py` as it is now fully covered by `TrajectoryState`.
- **Logging**:
  - Refactored `examples/eval_search.py` to use `report_metrics_from_dir` for cleaner metric reporting.
  - Refactored `setup_inference_logging` in `lits_benchmark` to support optional arguments.
- **BlocksWorld Transition & Reward**:
  - Renamed `GenerativeBwPRM` to `EnvGroundedPRM` and updated prompt registry accordingly.
  - Removed `buffered_action` and related logic from `EnvState` and other classes.
  - Removed reward logic from `EnvStep` to separate concerns.
  - Updated `EnvChain` and `ReAct` agents to support state overriding/resuming with query handling.
  - Removed duplicate `goal_check` in `lits/components/transition/blocksworld.py`; now uses `lits_benchmark.blocksworld.goal_check`.
  - Updated `BlocksWorldTransition.step` to strictly accept `query_or_goals` as `str` to resolve ambiguity.
  - Aligned `BlocksWorldTransition.step` arguments with `EnvChain` interface (renamed `action` to `step_or_action`, `goals` to `query_or_goals`).
  - Updated `GenerativeBwPRM` to support prompt-based scoring (Yes/No) for Bedrock models and accept `query_or_goals` in `_fast_reward`.

### Fixes
- Fixed `EnvChain` execution loop to correctly pass arguments to `world_model.step`.

## 2025-12-11  v0.2.5

### Fixed
* Made lits.benchmarks a separate package: `lits-benchmark`

## 2025-12-10  v0.2.5

### Added
- STATE_REGISTRY for State type deserialization
- Token usage metrics logging in eval_search.py
- Comprehensive serialization documentation in docs/eval/SERIALIZATION.md

### Fixed
- Build state dictionary including kwargs
- ToolUseAction and StringAction registered in TYPE_REGISTRY
- Action deserialization in SearchNode.from_dict()
- TrajectoryState serialization format updated with type information
  - TrajectoryState.to_dict() returns dict with __type__ and steps fields (was list)
  - TrajectoryState.save() includes query in serialized dict
  - TrajectoryState.load() extracts query from serialized dict
- `_serialize_obj` checks for custom to_dict() method before dataclass serialization
- `_deserialize_obj` handles State types with from_dict() method


### Removed 

## 2025-12-08  v0.2.5
### Added
- ToolUsePRM._complete_trajectory
  - saves rollout trajectories to result_dir/tool_use_prm_rollouts
  - saves with unique filenames like rollout_{query_idx}_{idx_rollout}.jsonl,

### Fixed
- ToolUsePRM
  - use max_length evaluation
  - use `from_phase+="_prm"` for policy call

## 2025-12-07  v0.2.5
### Changed
- Transition.step() interface redesigned to accept Step objects instead of just Actions
- ToolUseTransition now handles answer/error/malformed steps directly without execution
- ReActChat updated to pass full steps to transition model
- ToolUsePRM updated to require ToolUseStep (no longer accepts raw ToolUseAction)
- ToolUsePRM avoids redundant tool execution if step already has observation

## 2025-12-07  v0.2.5 (Unify tree search for tool use)
### Changed
- SearchNode serialization includes full step information (answer, error fields)
- Tree search components pass steps to both transition.step() and reward_model.fast_reward() (backward compatible with actions for QA tasks), including
  - _world_modeling passes steps
  - _assign_fast_reward() helper centralizes fast_reward assignment in _expand and _world_modeling

### Added
- ToolUsePRM saves rollout trajectories with unique filenames (rollout_{query_idx}_{idx_rollout}.jsonl)
- ToolUsePRM caches reward scores to avoid redundant evaluations


## 2025-12-06  v0.2.5
### Added

- ToolUsePRM (`lits/components/reward/tool_use.py`)

## 2025-12-05  v0.2.5

### Added
- **Post-Generation Callbacks**: Added `Policy.set_post_generation_fn()` for action validation after generation
  - Called after actions generated but before returned to agent
  - Receives `(steps, context)` with full generation context including `policy_model_name` and `task_type`
  - Use for validation, logging, or saving results without modifying agent logic
- **Automatic Learning Loop**: ReActChat now supports automatic setup with evaluators
  - Pass `step_evaluators` for per-step validation (e.g., SQLValidator)
  - Pass `trajectory_evaluators` for post-trajectory analysis (e.g., SQLErrorProfiler)
  - Automatically sets up dynamic notes (input enhancement) and validation (output validation)
  - Creates feedback loop: past issues → prompt → generate → validate → save → repeat
- **Demo Scripts**: 
  - `demo_learning_loop.py`: Complete learning loop example with both evaluator types
- **Documentation**: 
  - Added `docs/agents/LEARNING_LOOP.md` for automatic learning loop setup and usage

### Changed
**Some improvements during debugging the verbal evaluation feedback loop (BEGIN)**
- `get_dynamic_notes` directly returns the concatenated prompt string from `VerbalEvaluator.load_eval_as_prompt` for clean code and to retain the prefix of each section of issues
- **VerbalEvaluator Improvements**: Enhanced base class with unified interface and intelligent ranking
  - **Unified `evaluate()` method**: All evaluators implement consistent interface returning `Optional[str]`
  - **Standardized output**: All evaluators save `issues` as list of strings (removed `reasoning` field from SQLValidator)
  - **Improved `load_eval_as_prompt()`**: 
    - Issue-level granularity: Treats each issue as individual item (not records)
    - Score-based ranking: Prioritizes worst issues (lower scores) for maximum learning impact
    - `max_items` now refers to number of individual issues, not records
- **SQL Validator**
  - Saved `sql_query` for the result
  - **State Context for Validation**: Step-level evaluators now receive trajectory history (action-observation pairs via `ToolUseState.render_history()`) as context for more informed SQL validation decisions
**Some improvements during debugging the verbal evaluation feedback loop (END)**
- **ReActChat**: Added support for step-level and trajectory-level evaluators
  - Added `step_evaluators` parameter for per-step validation
  - Added `trajectory_evaluators` parameter for post-trajectory analysis
  - Added `_setup_learning_loop()` method for automatic callback configuration
  - Added `_evaluate_trajectory()` method called after `run()` completes
- **create_tool_use_agent()**: Updated parameters for clearer evaluator separation
  - Added `step_evaluators` parameter (replaces generic `evaluators`)
  - Added `trajectory_evaluators` parameter for trajectory-level analysis
  - Automatically configures learning loop when evaluators provided
  - Passes `policy_model_name` and `task_type` to ReActChat for callback context


## 2025-12-04  v0.2.5

### Added
- **Verbal Evaluator Base Class**: Created abstract `VerbalEvaluator` base class providing unified architecture for all verbal evaluators
  - Unified file management: All evaluators for same policy/task save to single file
  - Automatic metadata: Adds `evaluator_type` and `timestamp` to all records
  - Result filtering: Load results by evaluator type
  - Shared methods: `_get_result_saver()`, `_save_eval()`, `load_results()`
- **Unified Data Format**: Standardized output format across all verbal evaluators
  - All evaluators now save `issues` as a list for consistency
  - Unified schema: `{evaluator_type, query_idx, timestamp, issues, ...}`
  - Pandas-friendly format for easy DataFrame conversion
- **Unified `load_eval_as_prompt()`**: Moved to base class with evaluator-type grouping
  - Single implementation works for all evaluators
  - Groups results by `evaluator_type` for clear feedback
  - Optional `include_all_evaluators` parameter to load from all evaluators
- **Model Name Utility**: Added `get_clean_model_name()` in `lits.lm` module
  - Extracts clean, abbreviated model names for file naming
  - Example: `"bedrock/anthropic.claude-3-5-sonnet-20240620-v1:0"` → `"v1_0"`
- **Demo Script**: Added `demo_load_evaluations.py` to demonstrate unified storage
  - Loads and displays results as pandas DataFrame
  - Shows formatted prompts for policy injection
  - Verifies unified format across evaluators
- **Documentation**: 
  - Updated `docs/components/verbal_evaluator/VERBAL_EVALUATOR.md` with base class architecture
  - Added `docs/components/callback.md` for dynamic notes injection

### Changed
- **Refactored SQL Validator**: Now inherits from `VerbalEvaluator` base class
  - Removed duplicate `_get_result_saver()` and `_save_eval()` methods
  - Uses unified `load_eval_as_prompt()` from base class
  - Saves `issues` as list instead of single string
- **Refactored SQL Error Profiler**: Now inherits from `VerbalEvaluator` base class
  - Removed duplicate file management methods
  - Uses unified `load_eval_as_prompt()` from base class
  - Already used list format for `issues`
- **Unified File Storage**: Changed from separate files per evaluator to single shared file
  - Old: `resultdicttojsonl_{model}_{task}_validator.jsonl` and `resultdicttojsonl_{model}_{task}_profiler.jsonl`
  - New: `resultdicttojsonl_{model}_{task}.jsonl` (both evaluators)
  - Records distinguished by `evaluator_type` field


### Fixed
- Fixed test files to use unified `max_items` parameter instead of `max_issues`/`max_profiles`

### Benefits
- **Simplified Architecture**: Single base class eliminates code duplication
- **Unified Storage**: All evaluators share files, easier to manage and analyze
- **Consistent Format**: Pandas-friendly schema across all evaluators
- **Extensible**: Easy to create new evaluators by inheriting from base class
- **Maintainable**: Changes to file management or loading logic in one place

## 2025-12-03  v0.2.5

### Added
- **Dynamic Notes Injection**: Added callback-based system for injecting dynamic notes from external sources into policy system prompts
  - Added `Policy.set_dynamic_notes_fn()` method to register callback functions that return `List[str]` of notes
  - Added `Policy._get_dynamic_notes()` helper that retrieves and formats notes as bullet points
  - Added documentation in `docs/components/callback.md` with usage examples, best practices, and integration patterns
- **Policy System Prompt**: Refactored to handle dynamic notes in base class
  - `set_system_prompt()` now automatically appends dynamic notes
  - Subclasses only implement `_build_system_prompt()` for base prompt

## 2025-12-02  v0.2.5

### Added
- **SQL Validator Component**: Added LLM-based SQL query validation in `lits/components/verbal_evaluator/sql_validator.py`
- **SQL Error Profiler Component**: Added trajectory-level SQL error analysis in `lits/components/verbal_evaluator/sql_error_profiler.py`
- **Incremental Evaluation**: Added `evaluate_incremental()` to `GeneralEvaluator` f
- **ResultDictToCSV**: New result saver
- **Documentation**: Added `docs/eval/INCREMENTAL_EVALUATION.md` and `docs/eval/RESULT_SAVERS.md`

### Changed
- **Refactored `run_tree_search()`**: Separated tree search execution from evaluation; terminal nodes now saved to checkpoint files for post-processing
- **Error Handling**: Improved Bedrock API error messages to be concise (truncated from 100k+ to ~100 characters)

### Fixed
- Fixed `eval_result` not initialized when `include_input=False` in `GeneralEvaluator.evaluate()`

## 2025-12-01  v0.2.5

### Fixed
- Fixed `transition: ToolUseTransition` with tool exection 

### Added
- Added `transition: ToolUseTransition` parameter 
- **Documentation**: 
  - Added `docs/LITS_DESIGN.md`
  - Added `docs/components/transitions/TOOL_USE_TRANSITION.md` 

### Changed
- `ReActChat`: Updated to use explicit `ToolUseTransition` component

## 2025-11-30  v0.2.5

### Fixed
- Standardized all parameter names from `example_idx` to `query_idx` 
- **Argument Order**: Corrected `policy.get_actions()` call signature in tree search
  - Changed from `get_actions(example, node.state, ...)` to `get_actions(node.state, query=example, ...)`
  - Fixed in `bfs.py` and `common.py` helper functions

- **Type Parameter Fix**: Fixed `ToolUseTransition` class definition
  - Changed from `Transition[ToolUseState, ToolUseStep, str]` (3 params) to `Transition[ToolUseState, ToolUseStep]` (2 params)
  - Base `Transition` class only accepts 2 type parameters

- **Search Config Fix**: Fixed parameter mapping in `ExperimentConfig.to_search_config_dict()`
  - Added mapping: `policy_model_name` → `model_name` for `BaseConfig` compatibility
  - Ensures `BFSConfig` and `MCTSConfig` receive correct parameter names

- **Component Factory Fix**: Added `task_type` parameter to all LLM-based component instantiations
  - Updated: `RAPTransition`, `RAPPolicy`, `RapPRM`, `ConcatPolicy`, `GenerativePRM`, `ToolUsePolicy`, `ToolUsePRM`
  - Enables task-specific prompt loading from registry

- **Token Counting Fix**: Added cross-platform token counting support
  - Created `count_tokens()` utility function supporting HF models, OpenAI/Bedrock (via tiktoken), and fallback estimation
  - Fixed `ConcatPolicy` to work with non-HF models (Bedrock, OpenAI) that don't have tokenizer attribute

- **Policy Kwargs Fix**: Added `**kwargs` to policy `_get_actions()` signatures
  - Updated `ConcatPolicy` and `ToolUsePolicy` to accept optional parameters
  - Prevents errors when extra parameters are passed through base class

- **Policy Return Type Fix**: Fixed policies to return `Step` objects instead of raw strings
  - `ConcatPolicy`: Now returns `list[ThoughtStep]` wrapping action strings
  - `RAPPolicy`: Now returns `list[SubQAStep]` with sub_question, empty sub_answer, and 0.0 confidence
  - Updated `bfs_topk` and `mcts` to extract actions from Step objects using `.get_action()`
  - Ensures compliance with base `Policy` class contract expecting `List[StepT]`

### Changed
- **ConcatPolicy Refactoring**: Improved code organization and readability
  - Extracted constants: `SIMILARITY_THRESHOLD`, `MAX_TOKEN_LENGTH`, `MAX_RETRY_REPEAT`, `STEP_PREFIX_PATTERN`
  - Modularized monolithic `_get_actions()` into focused methods:
    - `_validate_task_prompt_spec()` - validation
    - `_generate_single_output()` - LLM calls
    - `_clean_output_text()` - text cleaning
    - `_is_valid_output()` - validation
    - `_log_validation_failure()` - logging
    - `_generate_action_with_retry()` - retry logic
    - `_check_similarity()` - similarity checking
  - Added comprehensive docstrings for all methods
  - Improved maintainability and testability

### Added
- **Debug Logging**: Added comprehensive debug logging for troubleshooting
  - Type checking and validation in `Policy.__init__`
  - Query type logging in `ConcatPolicy._generate_msg()`
  - Error details in `verbalize_concat_state()` for type mismatches

## 2025-11-28  v0.2.4

### Added
- **Config Refactoring**: Unified configuration system across all agent types
  - Added common attributes (`model_name`, `gpu_device`, `max_length`, `max_steps`) to `BaseConfig`
  - Replaced `depth_limit` with `max_steps` across `BaseSearchConfig`, `EnvChainConfig`, and `ReactChatConfig` for semantic consistency
  - Unified `to_dict()` and `save_config()` methods - now inherited from `BaseConfig` using `asdict()`
  - Updated all tree search algorithms (MCTS, BFS) and policies to use `max_steps`
  - Added `unit_test/test_config_refactoring.py` with 15 passing tests

- **Unified MCTS & BFS Interface**: Created consistent interface for tree search methods
  - Unified result structures: both `MCTSResult` and `BFSResult` now include:
    - `root` - root node of the search tree
    - `trace_of_nodes` - best path from root to terminal
    - `terminal_nodes_collected` - all terminal nodes found during search
  - Made `mcts()` and `bfs_topk()` function signatures nearly identical (only parameter names differ)
  - Extracted shared post-processing function: `extract_answers_from_terminal_nodes()` works for both MCTS and BFS
  - Unified `main_search_refactored.py` - same code handles both search methods transparently
  - Users no longer need to know which search method is used - identical interface for both

- **Tree Visualization Module** (`lits/visualize.py`): Comprehensive visualization tools for search trees
  - High-level functions:
    - `visualize_mcts_result()` - direct MCTS tree visualization
    - `visualize_bfs_result()` - direct BFS tree visualization
  - Mid-level functions:
    - `get_tree_from_result()` - extract paths from either result type
    - `plot_save_tree()` - visualize tree from paths
    - `buckets_to_paths()` - convert BFS buckets (breadth-wise) to paths (depth-wise)
  - Low-level functions:
    - `path_to_dict()` - convert node paths to dictionaries
    - `build_anytree_from_paths()` - build anytree structure with automatic node deduplication
    - `_make_label()` - generate node labels with symbols (⏹ terminal, ⇲ expanded, ∼ simulated)
  - Supports multiple output formats: PDF, PNG, SVG, DOT
  - Uses `anytree` and `graphviz` for publication-quality figures
  - Added `unit_test/test_visualization_demo.py` - creates real visualizations with mock trees
  - Added `unit_test/test_tree_visualization.py` - 10 passing tests

- **Documentation**: Comprehensive user guides and API references
  - Created `docs/agents/TREE_SEARCH_GUIDE.md` - complete user guide covering:
    - Quick start examples
    - Configuration for both MCTS and BFS
    - Result structure and post-processing
    - Visualization usage
    - Switching between methods
    - Advanced topics and best practices
  - Created `docs/TREE_VISUALIZATION.md` - visualization documentation with:
    - Installation requirements
    - Usage examples
    - API reference
    - Integration with search algorithms
  - Updated `README.md` with visualization section

- **Test Suite**: Comprehensive testing for new features
  - `unit_test/test_config_refactoring.py` - config system tests (15 tests)
  - `unit_test/test_tree_visualization.py` - visualization tests (10 tests)
  - `unit_test/test_tree_common.py` - shared utility tests
  - `unit_test/test_visualization_demo.py` - generates actual PDF visualizations
  - All tests passing ✅

### Changed
- **Removed Redundancy**: Eliminated duplicate code and storage
  - Removed `bucket_saver` - BFS now saves paths like MCTS for consistent storage format
  - Removed duplicate `to_dict()` methods from `EnvChainConfig` and `ReactChatConfig`
  - Extracted `buckets_to_paths()` to eliminate code duplication between visualization functions
  - Moved post-processing logic outside search algorithms for cleaner separation of concerns
  
- **Simplified BFS Implementation**:
  - Removed `retrieve_answer` and `return_buckets` parameters from `bfs_topk()`
  - Simplified `BFSResult` to only include core data: `root`, `terminal_nodes_collected`, `buckets_with_terminal`
  - Post-processing (vote_answers, answer_rewards) now done via shared `extract_answers_from_terminal_nodes()`

- **Updated MCTS Implementation**:
  - Added `terminal_nodes_collected` to `MCTSResult` for consistency with BFS
  - MCTS now collects terminal nodes recursively from the tree structure
  - Uses same post-processing function as BFS

### Fixed
- Fixed import errors:
  - `lits/agents/tree/continuation.py` - corrected `tree_search` → `tree`
  - `lits/agents/__init__.py` - corrected `react_chat` → `react`
  - `lits/agents/main.py` - corrected `EnvPolicy` → `EnvGroundedPolicy`
  - `lits/agents/chain/env_chain.py` - corrected `EnvPolicy` → `EnvGroundedPolicy`

### Benefits
- **Unified Interface**: Switch between MCTS and BFS without code changes
- **Consistent Storage**: Both methods use `TreeToJsonl` for path storage
- **Cleaner Code**: Eliminated duplication, separated concerns
- **Better Visualization**: Publication-quality tree visualizations with minimal code
- **Easier Maintenance**: Shared utilities reduce code duplication
- **Improved Testing**: Comprehensive test coverage for all new features

## 2025-11-27 (pdf_query_tool)
### Added
- Implemented PDF Query Tool for retrieving relevant content from PDF documents via URL
  - Added `PDFClient` in `lits/clients/pdf_client.py` for PDF downloading, parsing, chunking, and vector storage
  - Added `PDFQueryTool` in `lits/tools/pdf_tools.py` for agent integration
  - Uses Qdrant local vector database with SentenceTransformer embeddings
  - Supports configurable embedding model via `EMBEDDING_MODEL_NAME` environment variable
  - Implements UUID5-based point IDs for Qdrant compatibility
  - Validates PDF content with magic byte checking
  - Caches indexed documents for efficient repeated queries
- Added comprehensive documentation in `docs/PDF_QUERY_TOOL.md`
- Added unit tests in `unit_test/tools/test_pdf_tools.py` with real PDF downloads from arXiv
- Added dependencies: `pypdf`, `qdrant-client` to `pyproject.toml`

### Changed
- Updated `lits/tools/__init__.py` to register PDF tools via `build_tools(benchmark_name="pdf")`

## 2025-11-26 v0.2.4 (prompt_injection)
### Added
- Implemented dual-registry prompt injection system with separate registries for system prompts (`task_prompt_spec`) and user message templates (`usr_prompt_spec`)
- Added `PromptRegistry.register_usr()` method for registering user message templates
- Added `PromptRegistry.get_usr()` method for retrieving user message templates
- Added `LlmTransition` base class for LLM-based transitions with prompt management
- Updated `Policy` base class to load both `task_prompt_spec` and `usr_prompt_spec` independently from registries
- Updated `RewardModel` base class to load both prompt types independently from registries
- Updated `LlmTransition` base class to load both prompt types independently from registries
- Updated all Policy implementations to support independent prompt loading:
  - `RAPPolicy` - Updated `__init__` with new parameters
  - `ToolUsePolicy` - Updated to load PromptTemplate from registry and format with tools
  - `ConcatPolicy` - Updated `__init__` with new parameters
  - `EnvGroundedPolicy` - Updated `__init__` with new parameters
- Updated all RewardModel implementations to support independent prompt loading:
  - `RapPRM` - Updated `__init__` with new parameters
  - `GenerativePRM` - Updated `__init__` with new parameters
  - `SelfConsistencyRM` - Updated `__init__` with new parameters
  - `RLHFlowPRM` - Updated `__init__` with new parameters
- Updated all Transition implementations to inherit from `LlmTransition`:
  - `RAPTransition` - Now inherits from `LlmTransition`
  - `BlocksWorldTransition` - Now inherits from `LlmTransition`
  - `ConcatTransition` - Now inherits from `LlmTransition`
- Registered existing `usr_prompt_spec` entries in `load_default_prompts()`:
  - `lits.prompts.policy.rap.usr_prompt_spec_math_qa`
  - `lits.prompts.transition.rap.usr_prompt_spec_math_qa`
  - `lits.prompts.transition.blocksworld.usr_prompt_spec`
- Added comprehensive docstrings to base classes explaining:
  - `task_prompt_spec`: System-level instructions (system message)
  - `usr_prompt_spec`: User message structure (user message template)
  - Independent loading behavior with no priority between them
- Added unit tests in `unit_test/components/`:
  - `test_policy_reward_prompts.py` - Base class prompt loading tests
  - `test_llm_policy_components.py` - All Policy implementations tests
  - `test_llm_reward_components.py` - All RewardModel implementations tests
  - `test_llm_transition.py` - All Transition implementations tests
- Added comprehensive documentation:
  - `docs/PROMPT_INJECTION_DESIGN.md` - Complete design document with usage guide, code examples, best practices
  - Updated `README.md` with prompt injection section

### Changed
- Modified `PromptRegistry.clear()` to clear both `_registry` and `_usr_registry`
- Updated `load_default_prompts()` to register both system prompts and user templates
- Organized component test files into `unit_test/components/` folder for better organization

### Fixed
- Fixed `ToolUsePolicy` to properly pass `task_type` to parent class for registry loading
- Added missing `PromptTemplate` import in `lits/prompts/policy/tool_use.py`

## 2025-11-23 v0.2.3 (env_grounded)
### Added
- Added `EnvPolicy` class in `lits/components/policy/env_grounded.py` for environment-grounded action generation with comprehensive docstrings
- Added `EnvChain` agent in `lits/agents/chain/env_chain.py` for chain-like invocation of environment policies
- Added `create_env_chain_agent()` factory function in `lits/agents/main.py`
- Added trajectory tracking to `EnvState` via `history` field that accumulates all `EnvStep` objects
- Added serialization support for `EnvState` with `to_dict()`, `from_dict()`, `save()`, and `load()` methods
- Added unit tests:
  - `unit_test/test_state_serialization.py` - TrajectoryState serialization
  - `unit_test/test_env_state_serialization.py` - EnvState serialization
  - `unit_test/test_env_chain_trajectory.py` - Trajectory tracking
  - `unit_test/test_env_chain_history_accumulation.py` - History accumulation with new states

### Changed
- Moved `type_registry.py` from `lits/agents/tree_search/` to `lits/` to resolve circular import issues
- Made `lits/agents/__init__.py` use lazy imports via `__getattr__()` to prevent circular dependencies
- Moved serialization methods (`to_dict()`, `from_dict()`, `save()`, `load()`) from base `State` class to `TrajectoryState` class
- Updated `Step.to_dict()` to include `__type__` field for polymorphic deserialization
- Updated `State.from_dict()` to use type registry for dynamic Step subclass instantiation
- Updated `EnvChain.run()` to explicitly copy history from previous state to new state, ensuring trajectory accumulation regardless of world model implementation

### Fixed
- Fixed circular import between `lits.structures` and `lits.agents` by relocating type registry
- Fixed `EnvState` serialization error ("'EnvState' object is not iterable") by implementing state-specific serialization
- Fixed trajectory loss in `EnvChain` where only the most recent step was saved instead of the full action history

## 2025-11-21 v0.2.2 (memory)
### Added
- Implemented the LiTS-Mem subpackage (`lits/memory/`) containing `LiTSMemoryManager`, trajectory-aware configs, mem0/local backends, and retrieval utilities so tree-search agents can inherit and augment cross-trajectory memories.
- Added Unit tests
  - `unit_test/test_lits_memory_manager.py`
- Added `lits.clients.als_client.py` and `lits.tools.aws_geocode.AWSGeocodeTool`
- Added `lits.eval.general_eval.GeneralEvaluator` with flexible eval-block prompting plus `EvalPerspective` helpers, alongside `unit_test/test_general_eval.py`, to cover prompt construction, JSON parsing, and retry behaviour.
- Added `TrajectoryState` and `EnvState` base classes
  -  Further changed other `***State`, e.g., `ToolUseState` now inherits from `TrajectoryState`. `BWState` inherits from `EnvState`."
- Added `StringAction` base class in `base.py` for string-based actions. 
  - `ToolUseAction` and `EnvAction` now inherit from `StringAction`

### Changed
- Simplified `Policy` subclass implementation by using `**kwargs` in `__init__` and `_get_actions` method signature.

## v0.2.1
### Added
- Added `OpenAIChatModel`, `BedrockChatModel` support
- Added `get_fn_retrieve_answer_from_tool_use_state` 

### Changed
- Changed `make_retrieve_answer` to `get_fn_retrieve_answer_from_concat_state` 

## 2025-11-2 v0.2.0
### Added
- Introduced **unified `Tool` and `BaseClient` abstractions** for all tool-use scenarios:
  - `lits.tools.base.Tool`: defines the common interface (`name`, `description`, `args_schema`, `_run`).
  - `lits.clients.base_client.BaseClient`: defines the common client interface (`request`, `ping`).
- Added a new **`lits/clients/` subpackage** to separate backend connectivity from tool logic:
  - `web_client.py` for generic REST APIs.
  - `sql_client.py` for relational DBs.
  - `geosql_client.py` for spatial databases (GeoAlchemy).
  - `mapeval_client.py` as a specialized subclass of `WebServiceClient`.
- Refactored **SQL and geospatial tools** to align with the unified `Tool` ABC:
  - `lits.tools.sql_tools` wraps LangChain SQL tools while inheriting from `Tool`.
  - `lits.tools.geosql_tools` implements spatial functions and unique-value tools with unified semantics.

### Fixed
- Fixed Pydantic attribute conflict and Method Resolution Order (MRO) in multiple inheritance (`lits/tools/sql_tools.py`)
  - e.g., when subclassing LangChain’s `LCQuerySQLDatabaseTool` (a Pydantic `BaseModel`) together with our custom `BaseTool`

### Changed
- Changed package name: `langagent` -> `lits`. 
- Add `lits_llm` to build and distribute the package (LITS-LLM) on PyPI
- Add `examples` and `lits` into `lits_llm`

## 2025-10-21 v0.1.9
### Added
- Added `langagent/components/structures/trace.py` supplying `serialize_state`, `deserialize_state`, `log_state`, and `replay_state` so every reasoning paradigm can log and replay traces uniformly.
- Allowed `ReActChatPolicy` and `create_sys_msg` to accept an optional `tool_context` string so prompts can include high-level background before the tool list
- Compatible role interface and data structure fro tool use (**BIG Update**)
  - Introduced `ToolUsePolicy` so ReAct tool selection can be accessed through the generic `Policy` interface used by tree-search components
  - Refactored `ReActChat` and the CLUE/MapEval examples to delegate action generation to `ToolUsePolicy`, aligning the agent with the new abstractions
  - Centralized all step/state definitions under the new `langagent.components.structures` package and renamed `RapStep`→`SubQAStep`, `RestStep`→`ThoughtStep`, and `ReactState`→`ToolUseState`. 
    - Note: `langagent.reasoner_base` does not re-export these aliases for backward compatibility
- Extracted shared ReAct data structures and prompt helpers into `langagent.components.tool_use` for reuse across agents and policies

### Fixed
- Fixed the log file from the fixed `mcts_debug.log` to `f"{run_id}.log"` in `log.py`
- Prevented log handlers from accumulating across runs by scoping `setup_logging` to a per-run logger
- Hardened `verb_tool` to skip schema rendering when `args_schema` is not a Pydantic model class, preventing crashes from third-party tools

### Changed
- Added `langagent.agents.search.type_registry` and updated the search stack to consume it
  - Triggered by: circular imports in `agents.search.node` -> `components.structure.core` -> `type_registry` in `agents.search.node` 

## 2025-10-14 - v0.1.8 
### Added 
- Added `benchmarks` and put `langreason` directory into it
- Added `react_chat.py` for React Chat Agent (**BIG Update: ReAct**)
  - Added Checkpoints, i.e., resumable ReAct runs by checkpointing `ReactState` and reloading conversation history when a `checkpoint_path` is provided
  - Centralized tag parsing in `ReactStep` with configurable extractors and simplified `main_react.py` by delegating think/action/answer extraction
- Added `examples/mapeval` including original implemenation (`origin.ipynb`), from-scratch ReAct implementation (`main_react.py`), evaluation code (`eval.py`),  unit testing code (`test.ipynb`)
- Add `agents` directory and put `search` directory into it
- Added `tools` directory for tool inspection
  - Added MapEval tools in `tools/mapeval_tools.py`

### Modified
- Modified `BaseLLM` to set `max_new_tokens` and `max_length` with `_get_gen_legnth`, coordinating the default values from `__init__` and other invocation methods
- Updated `HfChatModel.tokenize` to allow multi-turn chatting
  - Purpose: preserve structured chat roles during ReAct loops and avoid hallucinated observations
  - But this is also a standardized implementations of ChatLLM

## - v0.1.7
### Added
- Added `examples/main_search.py` for general support (Untested)
- Added `examples/spatial_qa`
- Added unified dataset loading interface via huggingface datasets in `load_qa_dataset`
- Added yes-no evaluation to `eval_output`
  - Added `normalize_number_pair`, `normalize_yn` to `common.py`
- Added a new dataset `spart_yn` to `load_qa_dataset`
- Added `save_dir` to `RestEvaluator` to determine whether to save the correctness and usefulness results
- Added `spatial_qa` directory to `examples`
- Added `is_mcts_method` to `mcts_utils.py`


## - v0.1.6
### Added
- Added BN-SC2
  - `check_overlap_with_context` and `BNEvaluator.sc_eval()` to `mcts_utils.py`
- Added `runtime_limit_before_iter` to `BaseSearchConfig` for all the search methods

### Fixed
- Fixed the `expand_func` in `continuation` by adding `assign_rewards=False` 
- Used `verbalize_rap_state` and `verbalize_rest_state` in `mcts_utils.retrieve_answer` and remove `question` parameter from `common.extract_numerical_answer` 
- Fixed the issue in `mcts_utils.RAPWorldModel.step()` where `retrieve_answer_from_last_step`is called but returns empty string when the answer is not found

## 2025-09-20 - v0.1.4

### Added
- Added `verbalize_rap_state` to `mcts_utils.py`
- Added the RAP support for `BNEvaluator`

### Fixed (**BIG Update: RAP**)
- Fixed `RapEvaluator`, `RAPPolicy`
- Fixed `RAPPolicy`
  - Defined the prefix ( "Now we can answer the question: ") in `usr_msg_dict` from `framework_config.gsm8k_rap.actor_dynamics["overall_question_prefix"]`
- Fixed `BNEvaluator`
  - Fixed `entropy_eval` to only try a fixed number of times (Previously, although `success` was set to exit after the maxiumn number of tries, it was not used)
- Fixed `common.py` related to mcts
  - Fixed the issue that `fast_reward` is not assigned when calling `world_model.step` for mcts (unlike bfs, `fast_reward` and `reward` are required for backpropagration)
- Fixed `mcts.py`
  - `_output_iter` is set to `[]` (originally `None`) if no path leading to terminal state is found to avoid the issue when saved to JSON
  
### Removed
- Removed `terminal_state` from `MCTSResult`

### Added
- Added runtime limit for MCTS
- Added `bn_model_name` to `BaseSearchConfig` to allow users to customize the model for `BNEvaluator`

## 2025-09-17 - v0.1.3
### Added
- Added `mcts.py`
  - Added terimated paths after selection, continuation to `trace_in_each_iter`
  - Added `unselected_simulate` to save the unselected terminal paths during simulate
- Added `MCTSNode.from_continuation` to `node.py`

### Fixed
- Fixed `mcts.py` 
  - Remove `from_simulate` and use `from_phase` instead
  - Replace `is_expanded` with `from_expand`
- Fixed `bfs_topk` to correctly add terminal nodes to `terminal_nodes` (prevent duplicates)
- Fixed `bfs_topk` to not perform expansion if the last continuous node is a terminal node

### Added
- Added the function to return tree of nodes in `bfs_topk`
  - Added `return_buckets` in `bfs_topk`
  - Added `buckets_with_terminal` in `bfs_topk` to return buckets with all the nodes
- Added additional attributes to `BaseSearchConfig`
  - Added `bn_method`, `max_new_tokens_for_bn_eval`, `max_try_for_bn_eval`, and `package_version`

### Removed
- Removed the return of `reward_details` from `QAEvaluator.reward()` ({'r_useful': r_useful, 'r_conf': r_conf})

## 2025-09-15 - v0.1.2
### Fixed (**BIG Update**)
- Fixed `bfs_topk` for depth alignment of continuation and expansion

## 2025-09-12 - v0.1.1

### Fixed 
- Fixed `create_role` to handle `example_idx` correctly
    - Previously, `example_idx` was not added when it is 0
    - Previously, role in `RestWorldModel.is_terminal` has double underscores due to an additional `example_idx = f"_{example_idx}" if example_idx is not None else ''` before calling `create_role`
- Fixed the inclusion of `from_phase` for `role` in `RestEvaluator2`
- Fixed the inclusion of `from_phase="expand"` when calling `_expand_with_existing` in `bfs.bfs_topk`

### Added
- Added `bfs.py` (**BIG Update**)
    - Added `_expand_with_existing` for BFS with continuous phase
- Added `metrics.py` 
    - Added `get_inference_cost_metrics`

## 2025-09-09 - v0.1.0

### Fixed 
- Moved the answer-extraction logic from `langagent.search.mcts` to `mcts_utils` (`extract_answer_from_aggregation`
`extract_answer_from_dfs_path`)
- Only accepted non-terminal nodes for next-level search in `bfs_topk`
- Correctly added terminal nodes to `terminal_nodes` in `bfs_topk`
- Fixed `RestEvaluator` to use `get_next_token_logits` when generated score does not work

### Added
- Added `BNEvaluator` 
    - Added `entropy` (bne) and `direct` scoring
    - Added `extract_bne_output` to avoid the issue that the LLM returns a string wrapped around the target data structure (`list[dict]`)
- Added `langreason`
- Added `exploration.md`
- Added termination strategies:  `reward_threshold`, `binary_sampling`, `verify`
- Added critic
    - TODO: `incorrect_terminate`
- Added step/phase-wise memory (e.g., rest-mcts* critic) and instance-level memory (e.g.,  termination verification in `is_terminal` can modify the state, specifically the last `RestStep` in a state)
- Added `BaseSearchConfig` to share common parameters
- Added `BFSConfig` and `bfs_topk`

### Removed
- Removed `verbose` to control log writing in LangAgent (No Need since we have a gloabl control via `setup_logging`)

### TODO
- Prevented simulation nodes from being selected during the simulation phase 
